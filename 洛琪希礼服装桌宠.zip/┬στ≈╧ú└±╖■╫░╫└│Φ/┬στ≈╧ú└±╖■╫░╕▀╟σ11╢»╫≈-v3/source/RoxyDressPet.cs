﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Web.Script.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using System.Threading;
using System.Diagnostics;
using System.Globalization;
using Microsoft.Win32;

class RoxyDressPet {
    [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr h, int id, uint mod, uint key);
    [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr h, int id);
    [DllImport("user32.dll",SetLastError=true)] static extern UIntPtr SetTimer(IntPtr h,UIntPtr id,uint interval,IntPtr callback);
    [DllImport("user32.dll")] static extern bool KillTimer(IntPtr h,UIntPtr id);
    static readonly string Root = AppDomain.CurrentDomain.BaseDirectory;
    static readonly int[] Counts = {6,8,8,4,5,8,6,6,6,0,0};
    static readonly string[] Names = {"待机","向右跑","向左跑","挥手","跳跃","失落 / 哭泣","开心","思考","等待 / 观察","求吻","玩弄头发"};
    static int[][] frameDurations;
    static Dictionary<string,object> cfg;
    static readonly JavaScriptSerializer json = new JavaScriptSerializer();
    static BitmapImage[][] frames;
    static BitmapImage[][] hdFrames;
    static int canvasMode,dragDirection;
    static double canvasOffsetX,canvasOffsetY,dragLastX;
    static readonly UIntPtr DragTimerId=new UIntPtr(0x52445850);
    static UIntPtr activeDragTimer=UIntPtr.Zero;
    static int dragNativeTickCount;
    static bool dragOverride;
    static readonly Stopwatch dragClock=Stopwatch.StartNew();
    static Window window;
    static Image image;
    static MediaPlayer player;
    static DispatcherTimer timer, randomTimer;
    static ContextMenu menu;
    static MenuItem[] actionItems;
    static MenuItem intervalItem;
    static HwndSource source;
    static int row, frame;
    static bool soundPlaying, dragging, settingsOpen, smokeMode, verifyMode, runtimeFailed;
    static bool mouseDown, hovering;
    static Point downPoint;
    static Point lastPointerScreen;
    static bool pointerPositionKnown;
    static DateTime lastHover=DateTime.MinValue,lastClick=DateTime.MinValue,quietUntil=DateTime.MinValue;
    static readonly Dictionary<BitmapSource,byte[]> alphaCache=new Dictionary<BitmapSource,byte[]>();
    static readonly Random random=new Random();
    static int[] RandomActions={3,4,5,6,7,8};
    static double actionSeconds;
    static readonly Stopwatch animation=Stopwatch.StartNew();
    static string logPath=Path.Combine(Root,"礼服桌宠错误日志.txt");
    static void Log(string context, Exception ex) {
        string message=DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")+" "+context+"\r\n"+ex+"\r\n";
        try {File.AppendAllText(logPath,message);} catch { try {File.AppendAllText(Path.Combine(Path.GetTempPath(),"RoxyDressPet-error.log"),message);} catch { } }
    }
    static string ConfigPath { get { return Path.Combine(Root,"roxy-dress.config.json"); } }
    static Dictionary<string,object> Map(string key) { return (Dictionary<string,object>)cfg[key]; }
    static object Get(string map, int key) { object v; return Map(map).TryGetValue(key.ToString(), out v) ? v : null; }
    static bool ValidAction(int index) {return index>=0 && index<Counts.Length && Counts[index]>0;}
    static BitmapImage ReadFrame(string path) {
        var b=new BitmapImage(); b.BeginInit(); b.CacheOption=BitmapCacheOption.OnLoad;
        b.UriSource=new Uri(path); b.EndInit(); b.Freeze(); return b;
    }
    static void Load() {
        cfg = json.Deserialize<Dictionary<string,object>>(File.ReadAllText(ConfigPath));
        Map("audio"); Map("hotkeys"); Map("duration");
        Convert.ToDouble(cfg["volume"]); Convert.ToBoolean(cfg["mute"]);
        if(!cfg.ContainsKey("auto_random")) cfg["auto_random"]=true;
        Convert.ToBoolean(cfg["auto_random"]);
        if(!cfg.ContainsKey("random_interval")) cfg["random_interval"]=5.0;
        ValidateInterval(Convert.ToDouble(cfg["random_interval"]));
        frames = new BitmapImage[Counts.Length][];
        for (int r=0;r<Counts.Length;r++) {
            frames[r]=new BitmapImage[Counts[r]];
            for(int f=0;f<Counts[r];f++) {
                string path=Path.Combine(Root,"assets",r+"-"+f+".png");
                frames[r][f]=ReadFrame(path);
            }
            var audio=Get("audio",r) as string;
            if (!String.IsNullOrWhiteSpace(audio) && !File.Exists(Path.Combine(Root,audio))) throw new FileNotFoundException("音频文件不存在",audio);
        }
        var timeline=json.Deserialize<Dictionary<string,object>>(File.ReadAllText(Path.Combine(Root,"timeline.json")));
        frameDurations=json.ConvertToType<int[][]>(timeline["frame_ms"]);
        if(frameDurations.Length!=9)throw new InvalidDataException("动作时序行数错误");
        Array.Resize(ref frameDurations,Counts.Length);
        for(int r=0;r<9;r++) {
            if(frameDurations[r].Length!=Counts[r] || frameDurations[r].Any(ms=>ms<30 || ms>10000))throw new InvalidDataException("动作帧时长错误");
            foreach(var b in frames[r])if(b.PixelWidth!=192 || b.PixelHeight!=208)throw new InvalidDataException("礼服帧必须保留192×208完整画布");
        }
        LoadHd();
        RandomActions=Enumerable.Range(3,Counts.Length-3).Where(ValidAction).ToArray();
    }
    static BitmapImage FrameFor(int action,int index) {return (hdFrames[action]??frames[action])[index];}
    static BitmapImage CurrentFrame() {return FrameFor(row,frame);}
    static void ShowFrame(int action,int index) {
        image.Source=FrameFor(action,index);
        RenderOptions.SetBitmapScalingMode(image,hdFrames[action]!=null?BitmapScalingMode.HighQuality:BitmapScalingMode.NearestNeighbor);
    }
    static void LoadHd() {
        hdFrames=new BitmapImage[Counts.Length][];
        string manifest=Path.Combine(Root,"hd","manifest.json");if(!File.Exists(manifest))return;
        var resource=json.Deserialize<Dictionary<string,object>>(File.ReadAllText(manifest));
        var groups=json.ConvertToType<Dictionary<string,object>[]>(resource["groups"]);
        foreach(var group in groups) {
            int action=Convert.ToInt32(group["row"]);if(action<0||action>=Counts.Length||hdFrames[action]!=null)throw new InvalidDataException("高清动作编号无效或重复");
            string[] files=json.ConvertToType<string[]>(group["files"]);
            if(action>=9) {
                int[] durations=json.ConvertToType<int[]>(group["durations_ms"]);
                if(files.Length<2 || files.Length>64 || durations.Length!=files.Length || durations.Any(ms=>ms<30||ms>10000))throw new InvalidDataException("新增动作时序无效");
                Counts[action]=files.Length;frameDurations[action]=durations;
            }
            if(files.Length!=Counts[action])throw new InvalidDataException("必须提供整组高清帧，不得混用半组");
            int width=Convert.ToInt32(group["source_width"]),height=Convert.ToInt32(group["source_height"]);
            if(width<384 || width>1536 || width%192!=0 || height!=208*(width/192))throw new InvalidDataException("高清源必须保留192:208完整画布，至少2倍");
            if(Convert.ToDouble(group["anchor_x"])!=width/2.0 || Convert.ToDouble(group["anchor_y"])!=height)throw new InvalidDataException("高清锚点必须为源画布底部中心");
            var loaded=new BitmapImage[files.Length];string assetRoot=Path.GetFullPath(Path.Combine(Root,"hd"))+Path.DirectorySeparatorChar;
            for(int f=0;f<files.Length;f++) {
                string file=Path.GetFullPath(Path.Combine(assetRoot,files[f]));
                if(!file.StartsWith(assetRoot,StringComparison.OrdinalIgnoreCase))throw new InvalidDataException("高清资源路径越界");
                loaded[f]=ReadFrame(file);
                if(loaded[f].PixelWidth!=width||loaded[f].PixelHeight!=height||Math.Abs(loaded[f].DpiX-loaded[f].DpiY)>.01)throw new InvalidDataException("高清帧尺寸或像素比例不一致");
            }
            hdFrames[action]=loaded;
        }
    }
    static double CycleSeconds(int index) {return frameDurations[index].Sum()/1000.0;}
    static void Save() {
        string temp=ConfigPath+"."+Guid.NewGuid().ToString("N")+".tmp";
        try {File.WriteAllText(temp,json.Serialize(cfg),new System.Text.UTF8Encoding(false));File.Replace(temp,ConfigPath,null);}
        finally {if(File.Exists(temp))File.Delete(temp);}
    }
    static void Play(int index) {
        if(!ValidAction(index))throw new ArgumentOutOfRangeException("index");
        if(dragging)dragOverride=index!=0;
        ApplyCanvas(index,CurrentScale());
        row=index; frame=0; ShowFrame(row,frame);
        object duration=Get("duration",index);
        double seconds=duration==null ? CycleSeconds(index) : Convert.ToDouble(duration);
        if(Double.IsNaN(seconds)||Double.IsInfinity(seconds)||seconds<=0||seconds>3600)throw new InvalidDataException("动作时长必须在0到3600秒之间");
        actionSeconds=index==0 ? 0 : Math.Max(CycleSeconds(index),seconds); animation.Restart();
        player.Stop(); player.Close(); soundPlaying=false;
        string audio=Get("audio",index) as string;
        if (!Convert.ToBoolean(cfg["mute"]) && !String.IsNullOrWhiteSpace(audio)) {
            player.Volume=Math.Max(0,Math.Min(1,Convert.ToDouble(cfg["volume"])));
            player.Open(new Uri(Path.GetFullPath(Path.Combine(Root,audio)))); soundPlaying=true; player.Play();
        }
    }
    static int ChooseRandomAction() { return RandomActions[random.Next(RandomActions.Length)]; }
    static void ValidateInterval(double seconds) {
        if(Double.IsNaN(seconds)||Double.IsInfinity(seconds))throw new ArgumentException("请输入有效数字。");
        if(seconds<1)throw new ArgumentException("间隔至少为 1 秒。");
        if(seconds>2147483)throw new ArgumentException("间隔不能超过 2147483 秒。");
    }
    static double ParseInterval(string text) {
        if(String.IsNullOrWhiteSpace(text))throw new ArgumentException("请输入间隔秒数。");
        double value;if(!Double.TryParse(text.Trim(),NumberStyles.Float,CultureInfo.InvariantCulture,out value))throw new ArgumentException("请输入有效数字，单位为秒。");
        ValidateInterval(value);return value;
    }
    static string IntervalLabel() {return "随机动作间隔（"+Convert.ToDouble(cfg["random_interval"]).ToString("G",CultureInfo.InvariantCulture)+" 秒）…";}
    static void ChangeInterval(double seconds) {
        ValidateInterval(seconds);object old=cfg["random_interval"];TimeSpan before=randomTimer.Interval;
        try {cfg["random_interval"]=seconds;randomTimer.Interval=TimeSpan.FromSeconds(seconds);Save();if(intervalItem!=null)intervalItem.Header=IntervalLabel();}
        catch {cfg["random_interval"]=old;randomTimer.Interval=before;throw;}
    }
    static void EditInterval() {
        settingsOpen=true;
        var dialog=new Window {Title="随机动作间隔",Owner=window,Width=360,Height=230,WindowStartupLocation=WindowStartupLocation.CenterScreen,Topmost=true};
        var panel=new StackPanel {Margin=new Thickness(16)};
        panel.Children.Add(new TextBlock {Text="间隔单位为秒，最少 1 秒。动作或语音未结束时会跳过当次，不会中断。",TextWrapping=TextWrapping.Wrap});
        var box=new TextBox {Text=Convert.ToDouble(cfg["random_interval"]).ToString("G",CultureInfo.InvariantCulture),Margin=new Thickness(0,10,0,0),Padding=new Thickness(5)};panel.Children.Add(box);
        var message=new TextBlock {Foreground=Brushes.DarkRed,TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,5,0,0)};panel.Children.Add(message);
        var footer=new StackPanel {Orientation=Orientation.Horizontal,HorizontalAlignment=HorizontalAlignment.Right,Margin=new Thickness(0,10,0,0)};
        var save=new Button {Content="保存",Padding=new Thickness(12,4,12,4),Margin=new Thickness(0,0,8,0)};
        var cancel=new Button {Content="取消",Padding=new Thickness(12,4,12,4)};footer.Children.Add(save);footer.Children.Add(cancel);panel.Children.Add(footer);dialog.Content=panel;
        save.Click+=(s,e)=>{try {ChangeInterval(ParseInterval(box.Text));dialog.Close();}catch(ArgumentException ex){message.Text=ex.Message;}catch(Exception ex){Log("设置随机间隔失败",ex);message.Text="无法保存："+ex.Message;}};
        cancel.Click+=(s,e)=>dialog.Close();dialog.Closed+=(s,e)=>{settingsOpen=false;Quiet();};dialog.ShowDialog();
    }
    static void TryRandomAction(object sender,EventArgs e) {
        if(!Convert.ToBoolean(cfg["auto_random"]) || dragging || mouseDown || settingsOpen || DateTime.UtcNow<quietUntil || (menu!=null && menu.IsOpen) || actionSeconds>0 || soundPlaying) return;
        Play(ChooseRandomAction());
    }
    static void Tick(object sender, EventArgs e) {
        if(dragging && !dragOverride) {
            ShowFrame(dragDirection,dragDirection==0?IdleFrameAt(dragClock.ElapsedMilliseconds):FrameAtTime(dragClock.ElapsedMilliseconds,frameDurations[dragDirection]));return;
        }
        long elapsed=animation.ElapsedMilliseconds;
        if(actionSeconds>0 && elapsed>=actionSeconds*1000) {
            row=0;animation.Restart();elapsed=0;actionSeconds=0;
            if(dragging){dragOverride=false;ApplyCanvas(0,CurrentScale());Tick(sender,e);return;}
            ApplyCanvas(0,CurrentScale());
        }
        frame=FrameAtTime(elapsed,frameDurations[row]);
        ShowFrame(row,frame);
    }
    static int FrameAtTime(long elapsed,int[] durations) {
        long total=0;foreach(int ms in durations){if(ms<=0)throw new ArgumentException("帧时长必须大于零");total+=ms;}
        long t=elapsed%total;for(int i=0;i<durations.Length;i++){if(t<durations[i])return i;t-=durations[i];}return durations.Length-1;
    }
    static void BeginDragAnimation(double initialDx) {
        ApplyCanvas(0,CurrentScale());
        dragging=true;dragOverride=false;dragClock.Restart();row=0;frame=0;actionSeconds=0;animation.Restart();
        double dpi=source.CompositionTarget.TransformToDevice.M11;
        dragDirection=Math.Abs(initialDx*dpi)>=2?(initialDx>0?1:2):0;dragLastX=window.Left;
        ShowFrame(dragDirection,0);
        activeDragTimer=SetTimer(source.Handle,DragTimerId,30,IntPtr.Zero);
        if(activeDragTimer==UIntPtr.Zero)Log("拖动刷新计时器启动失败",new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error()));
    }
    static void UpdateDragDirection(double left) {
        if(!dragging)return;
        double dpi=source.CompositionTarget.TransformToDevice.M11;double delta=(left-dragLastX)*dpi;
        if(Math.Abs(delta)>=2){int next=delta>0?1:2;dragLastX=left;if(next!=dragDirection){dragDirection=next;dragClock.Restart();}}
    }
    static void EndDragAnimation() {
        if(!dragging)return;
        if(activeDragTimer!=UIntPtr.Zero && source!=null){KillTimer(source.Handle,activeDragTimer);activeDragTimer=UIntPtr.Zero;}
        dragging=false;if(!dragOverride || actionSeconds<=0){row=0;frame=0;actionSeconds=0;animation.Restart();}
        ApplyCanvas(row,CurrentScale());ShowFrame(row,frame);Quiet();
    }
    static int IdleFrameAt(long elapsed) { return FrameAtTime(elapsed,frameDurations[0]); }
    static bool DragThreshold(Point start,Point current) {return Math.Abs(current.X-start.X)>=4 || Math.Abs(current.Y-start.Y)>=4;}
    static void Quiet() {quietUntil=DateTime.UtcNow.AddSeconds(3);}
    static void Feedback(int index,double seconds) {
        if(actionSeconds>0 || soundPlaying)return;
        row=index;frame=0;actionSeconds=seconds;animation.Restart();ShowFrame(row,frame);Quiet();
    }
    static bool CharacterAt(Point p) {
        var bitmap=image.Source as BitmapSource;if(bitmap==null || image.ActualWidth<=0 || image.ActualHeight<=0)return false;
        double factor=Math.Min(image.ActualWidth/bitmap.PixelWidth,image.ActualHeight/bitmap.PixelHeight);
        double left=(image.ActualWidth-bitmap.PixelWidth*factor)/2, top=(image.ActualHeight-bitmap.PixelHeight*factor)/2;
        int x=(int)Math.Floor((p.X-left)/factor),y=(int)Math.Floor((p.Y-top)/factor);
        if(x<0||y<0||x>=bitmap.PixelWidth||y>=bitmap.PixelHeight)return false;
        byte[] data;if(!alphaCache.TryGetValue(bitmap,out data)) {var converted=new FormatConvertedBitmap(bitmap,PixelFormats.Bgra32,null,0);data=new byte[bitmap.PixelWidth*bitmap.PixelHeight*4];converted.CopyPixels(data,bitmap.PixelWidth*4,0);alphaCache[bitmap]=data;}
        return data[(y*bitmap.PixelWidth+x)*4+3]>=16;
    }
    static void HandleHover(bool inside,Point screen) {
        if(pointerPositionKnown && Math.Abs(screen.X-lastPointerScreen.X)<0.5 && Math.Abs(screen.Y-lastPointerScreen.Y)<0.5)return;
        pointerPositionKnown=true;lastPointerScreen=screen;
        if(!inside){hovering=false;return;}
        if(hovering)return;
        hovering=true;var now=DateTime.UtcNow;
        if(!mouseDown && !dragging && !settingsOpen && (menu==null || !menu.IsOpen) && now>=quietUntil && actionSeconds==0 && !soundPlaying && (now-lastHover).TotalSeconds>=12){lastHover=now;Feedback(4,CycleSeconds(4));}
    }
    static void HoverAt(Point p) {
        HandleHover(CharacterAt(p),image.PointToScreen(p));
    }
    static MenuItem AddItem(ContextMenu menu,string label,Action action) {
        var item=new MenuItem {Header=label}; item.Click+=(s,e)=>action(); menu.Items.Add(item);return item;
    }
    static string FormatShortcut(string value) {
        string[] parts=value.Split('+');for(int i=0;i<parts.Length;i++)parts[i]=parts[i].Trim();
        int last=parts.Length-1; if(parts[last].Length==2 && (parts[last][0]=='D'||parts[last][0]=='d') && Char.IsDigit(parts[last][1]))parts[last]=parts[last].Substring(1);
        return String.Join("+",parts);
    }
    static string StartupValue { get {return "\""+Path.Combine(Root,"洛琪希礼服装桌宠.exe")+"\"";} }
    static bool StartupEnabled(RegistryKey key) { return String.Equals(key.GetValue("RoxyDressPetStandalone") as string,StartupValue,StringComparison.OrdinalIgnoreCase); }
    static void SetStartup(RegistryKey key,bool enabled) {
        var value=key.GetValue("RoxyDressPetStandalone") as string;
        if(enabled) {
            if(!String.IsNullOrEmpty(value) && !String.Equals(value,StartupValue,StringComparison.OrdinalIgnoreCase)) throw new InvalidOperationException("另一份桌宠已设置开机自启，请先在那份程序中关闭。");
            key.SetValue("RoxyDressPetStandalone",StartupValue,RegistryValueKind.String);
        } else if(StartupEnabled(key)) key.DeleteValue("RoxyDressPetStandalone",false);
    }
    const string RunKey="Software\\Microsoft\\Windows\\CurrentVersion\\Run";
    static bool ReadStartup() { using(var key=Registry.CurrentUser.OpenSubKey(RunKey,false)) return key!=null && StartupEnabled(key); }
    static void ChangeStartup(bool enabled) { using(var key=Registry.CurrentUser.CreateSubKey(RunKey)) {if(key==null)throw new IOException("无法打开登录启动设置");SetStartup(key,enabled);} }
    static void UnregisterAll() {if(source!=null)for(int i=1;i<=Counts.Length;i++)UnregisterHotKey(source.Handle,i);}
    static void ParseShortcut(string text,out uint mods,out uint vk) {
        var parts=text.Split('+');if(parts.Length<2)throw new Exception("需要组合键");mods=0;
        for(int i=0;i<parts.Length-1;i++)switch(parts[i].Trim().ToLowerInvariant()){case "ctrl":mods|=2;break;case "alt":mods|=1;break;case "shift":mods|=4;break;case "win":mods|=8;break;default:throw new Exception("修饰键无效");}
        if((mods&3)==0 || (mods&8)!=0)throw new Exception("需要Ctrl或Alt，不能包含Win");
        var key=(Key)Enum.Parse(typeof(Key),parts[parts.Length-1].Trim(),true);int code=KeyInterop.VirtualKeyFromKey(key);
        if(code==0)throw new Exception("按键无效");vk=(uint)code;
    }
    static string RegisterBindings(Dictionary<string,object> bindings) {
        UnregisterAll();
        for(int i=0;i<Names.Length;i++)if(ValidAction(i))actionItems[i].Header=Names[i]+"（未设置快捷键）";
        var seen=new HashSet<string>(); var errors=new List<string>();
        foreach(var p in bindings) {
            int idx=-1; string label=Convert.ToString(p.Value);
            try {
                if(!Int32.TryParse(p.Key,out idx) || !ValidAction(idx))throw new Exception("动作编号无效或尚未启用");
                uint mods,vk;ParseShortcut(label,out mods,out vk);
                if(!seen.Add(mods+":"+vk))throw new Exception("与其他动作重复");
                if(!RegisterHotKey(source.Handle,idx+1,mods|0x4000,vk))throw new Exception("被系统或其他程序占用");
                actionItems[idx].Header=Names[idx]+"（"+FormatShortcut(label)+"）";
            } catch(Exception ex) {
                if(ValidAction(idx))actionItems[idx].Header=Names[idx]+"（"+FormatShortcut(label)+"，不可用）";
                errors.Add((ValidAction(idx)?Names[idx]:p.Key)+"："+FormatShortcut(label)+"，"+ex.Message);Log("快捷键注册失败",ex);
            }
        }
        return String.Join("\n",errors.ToArray());
    }
    static void ChangeVolume(double delta) {
        double old=Convert.ToDouble(cfg["volume"]); cfg["volume"]=Math.Round(Math.Max(0,Math.Min(1,old+delta)),1);
        try {Save(); player.Volume=Convert.ToDouble(cfg["volume"]);}
        catch(Exception ex) {Log("保存音量失败",ex); cfg["volume"]=old; MessageBox.Show("无法保存音量："+ex.Message);}
    }
    static double CurrentScale() {
        object value;double scale=cfg.TryGetValue("scale",out value)?Convert.ToDouble(value):1;
        return scale==1.5||scale==2?scale:1;
    }
    static void ApplyCanvas(int action,double scale) {
        if(source==null || window==null)return;
        var dpi=source.CompositionTarget.TransformToDevice;
        // Preserve the source cell's bottom-center anchor and never crop the skirt.
        double nextX=Math.Round(96*scale)/dpi.M11, nextY=Math.Round(208*scale)/dpi.M22;
        if(window.IsVisible){window.Left+=canvasOffsetX-nextX;window.Top+=canvasOffsetY-nextY;}
        window.Width=Math.Round(192*scale)/dpi.M11;
        window.Height=Math.Round(208*scale)/dpi.M22;
        image.Width=window.Width;image.Height=window.Height;image.Margin=new Thickness(0);
        canvasMode=action;canvasOffsetX=nextX;canvasOffsetY=nextY;
    }
    static void ResizePet(double scale) {ApplyCanvas(canvasMode,scale);}
    static void SetScale(double scale) {
        object old; bool had=cfg.TryGetValue("scale",out old); cfg["scale"]=scale;
        try {Save(); ResizePet(scale); ShowFrame(row,frame);} catch(Exception ex) {if(had)cfg["scale"]=old;else cfg.Remove("scale");Log("保存显示尺寸失败",ex);MessageBox.Show("无法保存显示尺寸："+ex.Message);}
    }
    static void EditShortcuts() {
        settingsOpen=true;UnregisterAll();bool saved=false;
        var dialog=new Window {Title="快捷键设置",Owner=window,Width=500,Height=650,WindowStartupLocation=WindowStartupLocation.CenterScreen,Topmost=true};
        var panel=new StackPanel {Margin=new Thickness(14)};
        panel.Children.Add(new TextBlock {Text="点击输入框并按组合键，需包含 Ctrl 或 Alt；清除后可用右键触发。",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,0,0,10)});
        var boxes=new TextBox[Names.Length];
        for(int i=0;i<Names.Length;i++) {
            if(!ValidAction(i))continue;
            int index=i; var line=new DockPanel {Margin=new Thickness(0,3,0,3)};
            var name=new TextBlock {Text=Names[i],Width=120,VerticalAlignment=VerticalAlignment.Center};DockPanel.SetDock(name,Dock.Left);line.Children.Add(name);
            var clear=new Button {Content="清除",Width=56,Margin=new Thickness(8,0,0,0)};DockPanel.SetDock(clear,Dock.Right);line.Children.Add(clear);
            string initial=Get("hotkeys",i) as string; var box=new TextBox {IsReadOnly=true,MinWidth=180,Padding=new Thickness(5),Tag=initial,Text=String.IsNullOrEmpty(initial)?"未设置快捷键":FormatShortcut(initial)};
            boxes[i]=box;line.Children.Add(box);panel.Children.Add(line);
            clear.Click+=(s,e)=>{boxes[index].Tag=null;boxes[index].Text="未设置快捷键";};
            box.PreviewKeyDown+=(s,e)=>{
                e.Handled=true;Key key=e.Key==Key.System?e.SystemKey:e.Key;var modifiers=Keyboard.Modifiers;
                if(key==Key.LeftCtrl||key==Key.RightCtrl||key==Key.LeftAlt||key==Key.RightAlt||key==Key.LeftShift||key==Key.RightShift||key==Key.LWin||key==Key.RWin)return;
                if((modifiers & (ModifierKeys.Control|ModifierKeys.Alt))==0 || (modifiers & ModifierKeys.Windows)!=0 || KeyInterop.VirtualKeyFromKey(key)==0){box.ToolTip="请按包含 Ctrl 或 Alt 的组合键";return;}
                string v=((modifiers&ModifierKeys.Control)!=0?"Ctrl+":"")+((modifiers&ModifierKeys.Alt)!=0?"Alt+":"")+((modifiers&ModifierKeys.Shift)!=0?"Shift+":"")+key;
                box.Tag=v;box.Text=FormatShortcut(v);box.ToolTip=null;
            };
        }
        var footer=new StackPanel {Orientation=Orientation.Horizontal,HorizontalAlignment=HorizontalAlignment.Right,Margin=new Thickness(0,12,0,0)};
        var defaults=new Button {Content="恢复默认",Padding=new Thickness(10,5,10,5),Margin=new Thickness(0,0,8,0)};
        var save=new Button {Content="保存",Padding=new Thickness(14,5,14,5),Margin=new Thickness(0,0,8,0)};
        var cancel=new Button {Content="取消",Padding=new Thickness(14,5,14,5)};
        footer.Children.Add(defaults);footer.Children.Add(save);footer.Children.Add(cancel);panel.Children.Add(footer);
        dialog.Content=new ScrollViewer {Content=panel,VerticalScrollBarVisibility=ScrollBarVisibility.Auto};
        defaults.Click+=(s,e)=>{for(int i=0;i<boxes.Length;i++){if(boxes[i]==null)continue;boxes[i].Tag=null;boxes[i].Text="未设置快捷键";}};
        cancel.Click+=(s,e)=>dialog.Close();
        save.Click+=(s,e)=>{
            var candidate=new Dictionary<string,object>();
            for(int i=0;i<boxes.Length;i++){if(boxes[i]==null)continue;string key=boxes[i].Tag as string;if(!String.IsNullOrEmpty(key))candidate[i.ToString()]=key;}
            string errors=RegisterBindings(candidate);
            if(!String.IsNullOrEmpty(errors)){UnregisterAll();MessageBox.Show(dialog,"以下快捷键不可用，请修改后重试：\n"+errors,"快捷键设置");return;}
            object old=cfg["hotkeys"];cfg["hotkeys"]=candidate;
            try {Save();saved=true;dialog.Close();}
            catch(Exception ex){cfg["hotkeys"]=old;UnregisterAll();Log("保存快捷键失败",ex);MessageBox.Show(dialog,"保存失败，原设置仍保留："+ex.Message,"快捷键设置");}
        };
        dialog.Closed+=(s,e)=>{if(!saved){string errors=RegisterBindings(Map("hotkeys"));if(!String.IsNullOrEmpty(errors))MessageBox.Show("原快捷键部分恢复失败：\n"+errors);}settingsOpen=false;Quiet();};
        dialog.ShowDialog();
    }
    static void Start() {
        window=new Window {Title="洛琪希礼服装单机桌宠", Width=192,Height=208,WindowStyle=WindowStyle.None,AllowsTransparency=true,Background=Brushes.Transparent,Topmost=true,ShowInTaskbar=false,UseLayoutRounding=true,SnapsToDevicePixels=true};
        window.Left=SystemParameters.WorkArea.Right-window.Width-20; window.Top=SystemParameters.WorkArea.Bottom-window.Height-20;
        image=new Image {Source=frames[0][0],SnapsToDevicePixels=true}; RenderOptions.SetBitmapScalingMode(image,BitmapScalingMode.NearestNeighbor); window.Content=image;ShowFrame(0,0);
        player=new MediaPlayer();
        player.MediaEnded+=(s,e)=>{soundPlaying=false;player.Close();};
        player.MediaFailed+=(s,e)=>{soundPlaying=false;Log("播放音频失败",e.ErrorException);MessageBox.Show("无法播放音频："+e.ErrorException.Message);};
        menu=new ContextMenu();
        actionItems=new MenuItem[Names.Length];
        for(int i=0;i<Names.Length;i++){if(!ValidAction(i))continue;int n=i;var key=Get("hotkeys",i) as string;string label=String.IsNullOrWhiteSpace(key)?"未设置快捷键":FormatShortcut(key)+"，注册中"; actionItems[i]=AddItem(menu,Names[i]+"（"+label+"）",()=>Play(n));}
        menu.Items.Add(new Separator());
        var mute=new MenuItem {Header="静音",IsCheckable=true,IsChecked=Convert.ToBoolean(cfg["mute"])};
        mute.Click+=(s,e)=>{bool old=Convert.ToBoolean(cfg["mute"]);cfg["mute"]=mute.IsChecked; try {Save();if(mute.IsChecked){player.Stop();player.Close();soundPlaying=false;}}catch(Exception ex){Log("保存静音失败",ex);cfg["mute"]=old;mute.IsChecked=old;MessageBox.Show("无法保存静音设置："+ex.Message);}};
        menu.Items.Add(mute); AddItem(menu,"音量 +10%",()=>ChangeVolume(0.1)); AddItem(menu,"音量 -10%",()=>ChangeVolume(-0.1));
        var auto=new MenuItem {Header="自动随机动作",IsCheckable=true,IsChecked=Convert.ToBoolean(cfg["auto_random"])};
        auto.Click+=(s,e)=>{bool old=Convert.ToBoolean(cfg["auto_random"]);cfg["auto_random"]=auto.IsChecked;try{Save();}catch(Exception ex){Log("保存自动动作设置失败",ex);cfg["auto_random"]=old;auto.IsChecked=old;MessageBox.Show("无法保存自动动作设置："+ex.Message);}};
        menu.Items.Add(auto);
        intervalItem=AddItem(menu,IntervalLabel(),EditInterval);
        AddItem(menu,"快捷键设置…",EditShortcuts);
        var startup=new MenuItem {Header="登录后自动启动",IsCheckable=true};menu.Items.Add(startup);
        menu.Opened+=(s,e)=>{mouseDown=false;Quiet();if(image.IsMouseCaptured)image.ReleaseMouseCapture();try{startup.IsChecked=ReadStartup();startup.IsEnabled=true;}catch(Exception ex){startup.IsEnabled=false;Log("读取登录启动设置失败",ex);}};
        menu.Closed+=(s,e)=>Quiet();
        startup.Click+=(s,e)=>{try{ChangeStartup(startup.IsChecked);startup.IsChecked=ReadStartup();}catch(Exception ex){Log("设置登录启动失败",ex);try{startup.IsChecked=ReadStartup();}catch{}MessageBox.Show("无法更改登录后启动："+ex.Message);}};
        var size=new MenuItem {Header="显示大小"}; menu.Items.Add(size);
        foreach(double n in new double[]{1.0,1.5,2.0}) {double v=n;var item=new MenuItem {Header=(int)(n*100)+"%"};item.Click+=(s,e)=>SetScale(v);size.Items.Add(item);}
        menu.Items.Add(new Separator()); AddItem(menu,"退出",()=>window.Close()); image.ContextMenu=menu;
        image.MouseMove+=(s,e)=>{
            Point p=e.GetPosition(image);HoverAt(p);
            if(mouseDown && e.LeftButton==MouseButtonState.Pressed && DragThreshold(downPoint,p)) {
                double initialDx=p.X-downPoint.X;
                mouseDown=false;Quiet();image.ReleaseMouseCapture();BeginDragAnimation(initialDx);
                try{window.DragMove();}finally{EndDragAnimation();}
            }
        };
        image.MouseLeave+=(s,e)=>{Point p=e.GetPosition(image);HandleHover(false,image.PointToScreen(p));};
        image.MouseLeftButtonDown+=(s,e)=>{Point p=e.GetPosition(image);if(CharacterAt(p)){downPoint=p;mouseDown=true;Quiet();image.CaptureMouse();e.Handled=true;}};
        image.MouseLeftButtonUp+=(s,e)=>{Point p=e.GetPosition(image);bool click=mouseDown && CharacterAt(p);mouseDown=false;if(image.IsMouseCaptured)image.ReleaseMouseCapture();Quiet();if(click && (DateTime.UtcNow-lastClick).TotalSeconds>=1){lastClick=DateTime.UtcNow;Feedback(3,CycleSeconds(3));}e.Handled=click;};
        image.LostMouseCapture+=(s,e)=>{mouseDown=false;};
        image.MouseRightButtonDown+=(s,e)=>{mouseDown=false;Quiet();if(image.IsMouseCaptured)image.ReleaseMouseCapture();};
        window.Deactivated+=(s,e)=>{mouseDown=false;if(image.IsMouseCaptured)image.ReleaseMouseCapture();};
        window.LocationChanged+=(s,e)=>{UpdateDragDirection(window.Left);};
        timer=new DispatcherTimer {Interval=TimeSpan.FromMilliseconds(30)}; timer.Tick+=Tick;
        randomTimer=new DispatcherTimer {Interval=TimeSpan.FromSeconds(Convert.ToDouble(cfg["random_interval"]))}; randomTimer.Tick+=TryRandomAction;
        window.SourceInitialized+=(s,e)=>{
            source=HwndSource.FromHwnd(new WindowInteropHelper(window).Handle);source.AddHook(Hook);
            object sizeValue; double scale=cfg.TryGetValue("scale",out sizeValue)?Convert.ToDouble(sizeValue):1.0;
            if(scale!=1.0 && scale!=1.5 && scale!=2.0) scale=1.0;
            ResizePet(scale);
            window.Left=SystemParameters.WorkArea.Right-window.Width-20;window.Top=SystemParameters.WorkArea.Bottom-window.Height-20;
            string errors=RegisterBindings(Map("hotkeys"));if(!String.IsNullOrEmpty(errors)){if(smokeMode){runtimeFailed=true;Log("启动检查时快捷键不可用",new InvalidOperationException(errors));}else MessageBox.Show("以下快捷键不可用：\n"+errors);}
        };
        window.Closed+=(s,e)=>{timer.Stop();randomTimer.Stop();if(activeDragTimer!=UIntPtr.Zero && source!=null){KillTimer(source.Handle,activeDragTimer);activeDragTimer=UIntPtr.Zero;}player.Close();UnregisterAll();};
        timer.Start(); randomTimer.Start(); var app=new Application(); app.DispatcherUnhandledException+=(s,e)=>{runtimeFailed=true;Log("界面异常",e.Exception);if(!smokeMode)MessageBox.Show("桌宠发生错误，详情已保存到日志："+e.Exception.Message);e.Handled=true;app.Shutdown();};
        if(smokeMode && !verifyMode) {
            var closeTimer=new DispatcherTimer {Interval=TimeSpan.FromSeconds(2)};
            closeTimer.Tick+=(s,e)=>{closeTimer.Stop();if(source==null || !window.IsVisible || !timer.IsEnabled || !randomTimer.IsEnabled){runtimeFailed=true;Log("启动检查失败",new InvalidOperationException("窗口或计时器未正常启动"));}window.Close();};
            closeTimer.Start();
        }
        if(verifyMode)window.ContentRendered+=(s,e)=>RunVerification();
        app.Run(window);
    }
    static IntPtr Hook(IntPtr h,int msg,IntPtr wp,IntPtr lp,ref bool handled) {
        if(msg==0x84 && !mouseDown && !dragging && image!=null && image.IsLoaded) {
            long pos=lp.ToInt64(); var p=image.PointFromScreen(new Point((short)(pos&65535),(short)((pos>>16)&65535)));
            if(!CharacterAt(p)){handled=true;return new IntPtr(-1);}
        }
        if(msg==0x113 && activeDragTimer!=UIntPtr.Zero && unchecked((ulong)wp.ToInt64())==activeDragTimer.ToUInt64()) {if(dragging){dragNativeTickCount++;Tick(null,EventArgs.Empty);}handled=true;return IntPtr.Zero;}
        if(msg==0x312){long id=wp.ToInt64(); if(id>=1 && id<=Counts.Length && ValidAction((int)id-1)){if(!settingsOpen)Play((int)id-1);handled=true;}} return IntPtr.Zero;
    }
    static void Require(bool value,string label) {if(!value)throw new Exception("验证失败："+label);}
    static void CheckResources() {
        for(int r=0;r<Counts.Length;r++) {
            if(!ValidAction(r))continue;
            long elapsed=0;
            for(int f=0;f<Counts[r];f++) {
                Require(FrameAtTime(elapsed,frameDurations[r])==f,"帧序起点");
                Require(FrameAtTime(elapsed+frameDurations[r][f]-1,frameDurations[r])==f,"帧序终点");
                elapsed+=frameDurations[r][f];
            }
            Require(FrameAtTime(elapsed,frameDurations[r])==0,"循环回首帧");
        }
        Require(!RandomActions.Any(n=>n<3 || !ValidAction(n)),"随机过滤");
        for(int i=0;i<500;i++)Require(RandomActions.Contains(ChooseRandomAction()),"随机选择");
        foreach(string invalid in new[]{"", "0", "NaN", "Infinity", "2147484", "abc"}) {
            bool rejected=false;try{ParseInterval(invalid);}catch(ArgumentException){rejected=true;}Require(rejected,"随机间隔拒绝无效值");
        }
        Require(ParseInterval("5")==5 && ParseInterval("1.25")==1.25,"随机间隔自定义");
        Require(!DragThreshold(new Point(0,0),new Point(3,3)) && DragThreshold(new Point(0,0),new Point(-4,0)),"拖动阈值");
    }
    static void RunVerification() {
        var results=new List<string>();byte[] original=File.ReadAllBytes(ConfigPath);
        var saved=json.Serialize(cfg);int active=-1;var seen=new HashSet<int>();
        var verifyTimer=new DispatcherTimer {Interval=TimeSpan.FromMilliseconds(30)};
        Action finish=()=>{verifyTimer.Stop();try{cfg=json.Deserialize<Dictionary<string,object>>(saved);File.WriteAllBytes(ConfigPath,original);UnregisterAll();}catch(Exception ex){runtimeFailed=true;results.Add(ex.ToString());}
            File.WriteAllText(Path.Combine(Root,"verification-results.json"),json.Serialize(new{passed=!runtimeFailed,checks=results,physical_input_tested=false}));window.Close();};
        try {
            CheckResources();results.Add("资源、全部动作帧序边界、随机过滤及间隔解析通过");
            cfg["auto_random"]=false;cfg["audio"]=new Dictionary<string,object>();
            double anchorX=window.Left+canvasOffsetX,anchorY=window.Top+canvasOffsetY;
            foreach(double scale in new[]{1.0,1.5,2.0}) {
                cfg["scale"]=scale;ResizePet(scale);window.UpdateLayout();
                var dpi=source.CompositionTarget.TransformToDevice;
                Require(Math.Abs(window.Width*dpi.M11-192*scale)<.01 && Math.Abs(window.Height*dpi.M22-208*scale)<.01,"物理像素尺寸");
                Require(Math.Abs(window.Left+canvasOffsetX-anchorX)<.01 && Math.Abs(window.Top+canvasOffsetY-anchorY)<.01,"缩放固定底部锚点");
                row=0;frame=0;ShowFrame(row,frame);window.UpdateLayout();
                var render=new RenderTargetBitmap((int)(192*scale),(int)(208*scale),96*dpi.M11,96*dpi.M22,PixelFormats.Pbgra32);render.Render(image);
                var encoder=new PngBitmapEncoder();encoder.Frames.Add(BitmapFrame.Create(render));
                using(var output=File.Create(Path.Combine(Root,"render-"+(int)(scale*100)+".png")))encoder.Save(output);
                for(int r=0;r<Counts.Length;r++)for(int f=0;f<Counts[r];f++) {
                    row=r;frame=f;ShowFrame(row,frame);ApplyCanvas(r,scale);window.UpdateLayout();
                    Require(Math.Abs(window.Left+canvasOffsetX-anchorX)<.01 && Math.Abs(window.Top+canvasOffsetY-anchorY)<.01,"切动作固定画布");
                    Require(!CharacterAt(new Point(-1,-1)),"画布外不命中");
                }
            }
            Require(RenderOptions.GetBitmapScalingMode(image)==(hdFrames[row]!=null?BitmapScalingMode.HighQuality:BitmapScalingMode.NearestNeighbor),"高清/原图采样模式");
            results.Add("三档实体像素尺寸、全部帧固定锚点、完整画布及按源选择采样通过");
            cfg["scale"]=1.0;ResizePet(1);Play(0);window.UpdateLayout();
            var bitmap=CurrentFrame();var pixels=new FormatConvertedBitmap(bitmap,PixelFormats.Bgra32,null,0);int bw=bitmap.PixelWidth,bh=bitmap.PixelHeight;var data=new byte[bw*bh*4];pixels.CopyPixels(data,bw*4,0);
            int opaque=0,transparent=0;
            for(int y=0;y<bh;y++)for(int x=0;x<bw;x++) {
                bool expected=data[(y*bw+x)*4+3]>=16;var point=new Point((x+.5)*image.ActualWidth/bw,(y+.5)*image.ActualHeight/bh);
                Require(CharacterAt(point)==expected,"逐像素透明命中");if(expected)opaque++;else transparent++;
            }
            Require(opaque>0 && transparent>0,"真实透明与人物区域");results.Add("待机首帧全部源像素透明命中通过");
            ChangeInterval(7.25);var disk=json.Deserialize<Dictionary<string,object>>(File.ReadAllText(ConfigPath));Require(Convert.ToDouble(disk["random_interval"])==7.25 && randomTimer.Interval.TotalSeconds==7.25,"配置和随机计时器同步");
            ChangeInterval(5.0);results.Add("独立配置原子保存、计时器同步和重读通过；结束后恢复原配置");
            uint mods,vk;ParseShortcut("Ctrl+Alt+F24",out mods,out vk);
            string errors=RegisterBindings(new Dictionary<string,object>{{"3","Ctrl+Alt+F24"},{"4","Alt+Ctrl+F24"}});
            Require(errors.Contains("重复"),"内部热键冲突");UnregisterAll();
            using(var other=new HwndSource(new HwndSourceParameters("RoxyDressHotkeyProbe"))) {
                Require(RegisterHotKey(other.Handle,999,mods|0x4000,vk),"测试热键未被占用");
                try{errors=RegisterBindings(new Dictionary<string,object>{{"3","Ctrl+Alt+F24"}});Require(errors.Contains("占用"),"系统级热键冲突");}finally{UnregisterHotKey(other.Handle,999);}
            }
            Require(RegisterBindings(new Dictionary<string,object>())=="","清空热键");results.Add("热键重复、系统占用及清空通过（临时F24组合，均已释放）");
            Require(ValidAction(9) && ValidAction(10) && actionItems[9]!=null && actionItems[10]!=null,"新增动作菜单");
            Require(RandomActions.Contains(9) && RandomActions.Contains(10) && !RandomActions.Contains(0) && !RandomActions.Contains(1) && !RandomActions.Contains(2),"新增动作随机池");
            var keys=new Dictionary<string,object>{{"9","Ctrl+Alt+Shift+F22"},{"10","Ctrl+Alt+Shift+F23"}};
            Require(RegisterBindings(keys)=="","新增动作快捷键注册");object oldKeys=cfg["hotkeys"];cfg["hotkeys"]=keys;Save();
            var loaded=json.Deserialize<Dictionary<string,object>>(File.ReadAllText(ConfigPath));var loadedKeys=(Dictionary<string,object>)loaded["hotkeys"];
            Require((string)loadedKeys["9"]=="Ctrl+Alt+Shift+F22" && (string)loadedKeys["10"]=="Ctrl+Alt+Shift+F23","新增快捷键保存重读");
            cfg["hotkeys"]=oldKeys;UnregisterAll();results.Add("新增动作菜单、随机池、快捷键注册与保存重读通过");
            actionSeconds=0;soundPlaying=false;quietUntil=DateTime.MinValue;hovering=false;pointerPositionKnown=false;lastHover=DateTime.MinValue;
            HandleHover(true,new Point(1,1));Require(row==4 && actionSeconds>0,"移入跳跃");
            Play(3);double before=actionSeconds;HandleHover(false,new Point(2,1));HandleHover(true,new Point(3,1));Require(row==3 && actionSeconds==before,"人工动作优先");
            Play(0);HandleHover(false,new Point(4,1));HandleHover(true,new Point(5,1));Require(row==0,"移入冷却");results.Add("移入跳跃、冷却、人工操作优先通过（处理函数模拟）");
            BeginDragAnimation(5);Require(dragDirection==1,"右拖右跑");UpdateDragDirection(window.Left-10);Require(dragDirection==2,"左拖左跑");
            UpdateDragDirection(window.Left+10);Require(dragDirection==1,"拖动切换方向");EndDragAnimation();Require(row==0 && !dragging && activeDragTimer==UIntPtr.Zero,"结束拖动回待机");
            results.Add("左右拖动及释放回待机通过（处理函数模拟）");Play(0);quietUntil=DateTime.UtcNow.AddMinutes(2);
            verifyTimer.Tick+=(sender,e)=>{
                try {
                    if(active>=0){if(row==active)seen.Add(frame);else{Require(row==0,"动作结束回待机");Require(seen.Count==Counts[active],"真实计时播放全部帧："+Names[active]);results.Add(Names[active]+"：真实计时完整帧序播放及回待机通过");active++;while(active<Counts.Length && !ValidAction(active))active++;seen.Clear();}}
                    else active=0;
                    if(active==0){seen.Add(frame);if(animation.ElapsedMilliseconds<CycleSeconds(0)*1000)return;Require(seen.Count==Counts[0],"待机真实计时播放全部帧");results.Add("待机：真实计时完整六帧循环通过");active=1;seen.Clear();Play(active);seen.Add(0);}
                    else if(active>=Counts.Length){finish();return;}
                    else if(row==0){Play(active);seen.Add(0);}
                }catch(Exception ex){runtimeFailed=true;results.Add(ex.ToString());finish();}
            };verifyTimer.Start();
        }catch(Exception ex){runtimeFailed=true;results.Add(ex.ToString());finish();}
    }
    [STAThread] static int Main(string[] args) {
        try {Load(); if(args.Contains("--check")){CheckResources();bool handled=false; Hook(IntPtr.Zero,0,new IntPtr(Int64.MaxValue),IntPtr.Zero,ref handled); Hook(IntPtr.Zero,0x312,new IntPtr(Int64.MaxValue),IntPtr.Zero,ref handled); return 0;}
            verifyMode=args.Contains("--verify");smokeMode=args.Contains("--smoke")||verifyMode;bool created; using(var mutex=new Mutex(true,"Local\\RoxyDressPetStandalone",out created)) {if(!created){if(!smokeMode)MessageBox.Show("桌宠已经运行，请先从现有桌宠的右键菜单退出。");return smokeMode?2:0;} Start();}return runtimeFailed?1:0;}
        catch(Exception ex){Log("启动或运行失败",ex);if(!args.Contains("--check")&&!args.Contains("--smoke")&&!args.Contains("--verify"))MessageBox.Show("桌宠启动失败："+ex.Message+"\n详情请查看礼服桌宠错误日志.txt");return 1;}
    }
}
