﻿$ErrorActionPreference = 'Stop'
$framework = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319'
$refs = @('System.dll','System.Core.dll','System.Web.Extensions.dll','System.Xaml.dll','WPF\WindowsBase.dll','WPF\PresentationCore.dll','WPF\PresentationFramework.dll') | ForEach-Object {'/reference:' + (Join-Path $framework $_)}
& (Join-Path $framework 'csc.exe') /nologo /target:winexe /platform:anycpu /optimize+ $refs ('/out:' + (Join-Path $PSScriptRoot '希露菲桌宠.exe')) (Join-Path $PSScriptRoot 'source\SylphiePet.cs')
if ($LASTEXITCODE -ne 0) {throw 'Compilation failed'}
