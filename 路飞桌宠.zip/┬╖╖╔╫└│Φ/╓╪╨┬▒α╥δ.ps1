﻿$ErrorActionPreference = 'Stop'
$framework = Join-Path $env:SystemRoot 'Microsoft.NET\Framework64\v4.0.30319'
$source = Join-Path $PSScriptRoot 'source'
$assets = Join-Path $source 'assets'
$refs = @('System.dll','System.Core.dll','System.Web.Extensions.dll','System.Xaml.dll','WPF\WindowsBase.dll','WPF\PresentationCore.dll','WPF\PresentationFramework.dll') |
    ForEach-Object { '/reference:' + (Join-Path $framework $_) }

& (Join-Path $framework 'csc.exe') /nologo /target:winexe /platform:anycpu /optimize+ /define:LUFFY $refs `
    ('/resource:' + (Join-Path $assets 'luffy-a.png') + ',sheet-a') `
    ('/resource:' + (Join-Path $assets 'luffy-b.png') + ',sheet-b') `
    ('/out:' + (Join-Path $PSScriptRoot '路飞桌宠.exe')) (Join-Path $source 'OnePiecePet.cs')
if ($LASTEXITCODE -ne 0) { throw '路飞桌宠编译失败' }
