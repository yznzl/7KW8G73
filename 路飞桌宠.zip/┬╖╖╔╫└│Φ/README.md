# 路飞桌宠

Windows 单机桌宠。双击同名 EXE 即可离线运行，动画素材已内置。需要 .NET Framework 4.x。

两套 Codex 路飞动画共 18 组。默认站立待机，右键「另一套动作」可选睡觉等动作。

左键点击人物挥手，拖动播放跑步动作。右键可选动作、调整大小、设置随机动作和快捷键，或退出程序。首次启动默认 150%。

## 从源码编译

在 Windows PowerShell 中运行 重新编译.ps1。脚本用系统自带的 .NET Framework C# 编译器和 source/assets 内的动画图集生成 EXE。
