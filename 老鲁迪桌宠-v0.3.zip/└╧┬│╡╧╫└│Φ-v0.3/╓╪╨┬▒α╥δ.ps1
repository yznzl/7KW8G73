$ErrorActionPreference = 'Stop'
$framework = 'C:\Windows\Microsoft.NET\Framework64\v4.0.30319'
$refs = @('System.dll','System.Core.dll','System.Web.Extensions.dll','System.Xaml.dll','WPF\WindowsBase.dll','WPF\PresentationCore.dll','WPF\PresentationFramework.dll') | ForEach-Object { '/reference:' + (Join-Path $framework $_) }
& (Join-Path $framework 'csc.exe') /nologo /target:winexe /platform:anycpu /optimize+ $refs ('/out:' + (Join-Path $PSScriptRoot '老鲁迪桌宠.exe')) (Join-Path $PSScriptRoot 'source\OldRudyPet.cs')
if ($LASTEXITCODE -ne 0) { throw 'Compilation failed' }
Write-Output '编译完成；现有动作清单、素材与配置均保留。'
