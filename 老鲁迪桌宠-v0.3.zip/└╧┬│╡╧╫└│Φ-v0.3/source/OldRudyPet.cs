﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Diagnostics;
using System.ComponentModel;
using System.Runtime.InteropServices;
using System.Threading;
using System.Web.Script.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

public class SizeSpec { public int width { get; set; } public int height { get; set; } }
public class AnchorSpec { public double x { get; set; } public double y { get; set; } }
public class FrameSpec {
    public string path { get; set; }
    public int durationMs { get; set; }
}
public class ActionSpec {
    public string id { get; set; }
    public string label { get; set; }
    public bool placeholder { get; set; }
    public bool loop { get; set; }
    public string next { get; set; }
    public int durationMs { get; set; }
    public FrameSpec[] frames { get; set; }
    public FrameSpec[] effects { get; set; }
}
public class Manifest {
    public int version { get; set; }
    public SizeSpec canvas { get; set; }
    public AnchorSpec anchor { get; set; }
    public ActionSpec[] actions { get; set; }
}
public class Settings {
    public double? left { get; set; }
    public double? top { get; set; }
    public double scale { get; set; }
    public bool autoRandom { get; set; }
    public Dictionary<string, string> hotkeys { get; set; }
    public Settings() { scale = 1; autoRandom = true; hotkeys = new Dictionary<string, string>(); }
}

// Playback uses elapsed time, so delayed dispatcher callbacks never lengthen reach.
public class Playback {
    public readonly Dictionary<string, ActionSpec> actions;
    public ActionSpec current;
    public long started;
    public Playback(Manifest manifest) {
        actions = manifest.actions.ToDictionary(a => a.id);
        current = HasFrames("seated_idle") ? actions["seated_idle"] : actions["idle"];
    }
    public bool HasFrames(string id) { ActionSpec a; return actions.TryGetValue(id, out a) && !a.placeholder && a.frames != null && a.frames.Length > 0; }
    public bool Available(string id) {
        ActionSpec a;
        if (!actions.TryGetValue(id, out a) || !HasFrames(id)) return false;
        return a.loop || HasFrames(a.next);
    }
    public bool Select(string id, long now) {
        if (current.id == "reach" && now - started < 5000) return false;
        current = actions[id]; started = now; return true;
    }
    public void Advance(long now) {
        if (!current.loop && now - started >= current.durationMs) {
            current = actions[current.next]; started = now;
        }
    }
    public long Elapsed(long now) { return Math.Max(0, now - started); }
    public static int FrameAt(FrameSpec[] frames, long elapsed, bool loop) {
        if (frames.Length == 0) return -1;
        long total = frames.Sum(f => (long)f.durationMs);
        long time = loop ? elapsed % total : Math.Min(elapsed, total - 1);
        for (int i = 0; i < frames.Length; i++) {
            if (time < frames[i].durationMs) return i;
            time -= frames[i].durationMs;
        }
        return frames.Length - 1;
    }
}

class OldRudyPet {
    static readonly string Root = AppDomain.CurrentDomain.BaseDirectory;
    static readonly JavaScriptSerializer Json = new JavaScriptSerializer();
    static readonly string[] Ids = { "idle", "remember", "warning", "grief", "reach", "lightning", "time_return", "seated_idle" };
    static readonly Stopwatch Clock = Stopwatch.StartNew();
    static readonly Random Random = new Random();
    static Manifest manifest;
    static Settings settings;
    static Playback playback;
    static Window window;
    static Canvas canvas;
    static Image character, effects;
    static Border placeholder, badge;
    static TextBlock title, detail, badgeText;
    static ContextMenu menu;
    static List<MenuItem> actionItems;
    static DispatcherTimer timer;
    static HwndSource source;
    static bool pressed, dragging, smoke, smokeTime, smokeIdle, smokeSeat, smokeAll, diagnostics, failed;
    static Point downScreen, lastScreen;
    static long nextRandom, smokeStarted, lastTrace;
    static readonly string[] RandomIds = { "remember", "warning", "grief", "reach", "lightning", "time_return" };
    static bool smokeLockChecked, timePreviewSaved;
    static readonly List<object> events = new List<object>();
    const int FrameCacheLimit = 8;
    static readonly Dictionary<string, BitmapSource> frameCache = new Dictionary<string, BitmapSource>(StringComparer.OrdinalIgnoreCase);
    static readonly List<string> frameOrder = new List<string>();
    static BitmapSource hitBitmap;
    static byte[] hitPixels;
    static byte[] decodeScratch;
    static int evictionsSinceCollection;
    static long slowestFrameDecodeMs;
    static int maxCachedFrames;
    static readonly List<string> allQueue = new List<string>(), allSkipped = new List<string>();
    static readonly List<object> allResults = new List<object>();
    static readonly HashSet<int> allObservedFrames = new HashSet<int>();
    static int allIndex;
    static int shownFrame;
    static string shownAction;
    static bool allCaptured, allFramesCovered = true;
    static long allCaptureMs;
    static double allLeft, allTop, allWidth, allHeight;

    static void Require(bool value, string message) { if (!value) throw new InvalidDataException(message); }
    static bool Finite(double value) { return !Double.IsNaN(value) && !Double.IsInfinity(value); }
    static string AssetPath(string path) {
        Require(!String.IsNullOrWhiteSpace(path) && !Path.IsPathRooted(path), "帧路径必须为包内相对路径。");
        string full = Path.GetFullPath(Path.Combine(Root, path));
        Require(full.StartsWith(Root, StringComparison.OrdinalIgnoreCase) &&
            String.Equals(Path.GetExtension(full), ".png", StringComparison.OrdinalIgnoreCase), "帧路径越界或不是 PNG：" + path);
        // Disallow symlinks/junctions as well as textual traversal out of the package.
        for (string p = full; p != null && p.StartsWith(Root, StringComparison.OrdinalIgnoreCase); p = Path.GetDirectoryName(p)) {
            if (File.Exists(p) || Directory.Exists(p))
                Require((File.GetAttributes(p) & FileAttributes.ReparsePoint) == 0, "素材路径不能经过链接：" + path);
        }
        return full;
    }
    static void Validate(Manifest m, bool images) {
        Require(m != null && m.version == 1, "不支持的动作清单版本。");
        Require(m.canvas != null && m.canvas.width >= 128 && m.canvas.width <= 2048 && m.canvas.height >= 128 && m.canvas.height <= 2048, "画布须在 128～2048 像素之间。");
        Require(m.anchor != null && Finite(m.anchor.x) && Finite(m.anchor.y) && m.anchor.x >= 0 && m.anchor.x < m.canvas.width && m.anchor.y >= 0 && m.anchor.y < m.canvas.height, "脚底锚点必须在画布内。");
        Require(m.actions != null && m.actions.Length == Ids.Length, "必须含全部 8 个动作。");
        var seen = new HashSet<string>();
        var decoded = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        byte[] validationPixels = images ? new byte[m.canvas.width * m.canvas.height * 4] : null;
        foreach (var a in m.actions) {
            Require(a != null && a.id != null && Ids.Contains(a.id) && seen.Add(a.id), "存在未知或重复动作 ID。");
            Require(!String.IsNullOrWhiteSpace(a.label) && a.label.Length <= 80, "动作名称缺失或过长。");
            Require(a.durationMs > 0 && a.durationMs <= 60000, "动作时长无效：" + a.id);
            bool loop = a.id == "idle" || a.id == "seated_idle";
            string next = a.id == "time_return" || a.id == "seated_idle" ? "seated_idle" : "idle";
            Require(a.loop == loop && a.next == next, "动作循环/结束设置不符合接口：" + a.id);
            Require(a.id != "reach" || a.durationMs == 5000, "reach 必须为 5000ms。");
            Require(a.id != "time_return" || (a.durationMs >= 5000 && a.durationMs <= 7000), "time_return 须为 5000～7000ms。");
            Require(a.frames != null && a.effects != null, "frames/effects 数组不可省略：" + a.id);
            Require(a.placeholder || a.frames.Length > 0, "正式动作没有角色帧：" + a.id);
            Require(a.id == "lightning" || a.id == "time_return" || a.effects.Length == 0, "仅 lightning 和 time_return 接受特效帧。");
            Require(a.placeholder || a.id != "lightning" || a.effects.Length > 0, "正式雷电动作必须提供独立 effects 帧。");
            foreach (var sequence in new[] { a.frames, a.effects }) {
                Require(sequence.Length <= 600, "单序列帧数超过 600。");
                if (sequence.Length > 0) Require(sequence.All(f => f != null && f.durationMs > 0) && sequence.Sum(f => (long)f.durationMs) == a.durationMs, "逐帧时长之和必须等于动作时长：" + a.id);
                foreach (var f in sequence) {
                    string path = AssetPath(f.path);
                    if (!images) continue;
                    if (!decoded.Add(path)) continue;
                    var b = new BitmapImage();
                    b.BeginInit(); b.CacheOption = BitmapCacheOption.OnLoad; b.UriSource = new Uri(path); b.EndInit(); b.Freeze();
                    Require(b.PixelWidth == m.canvas.width && b.PixelHeight == m.canvas.height, "帧尺寸与画布不一致：" + f.path);
                    var converted = new FormatConvertedBitmap(b, PixelFormats.Bgra32, null, 0);
                    converted.CopyPixels(validationPixels, b.PixelWidth * 4, 0);
                    if (decoded.Count % 16 == 0) { GC.Collect(); GC.WaitForPendingFinalizers(); }
                }
            }
        }
    }
    static BitmapSource FrameBitmap(FrameSpec f) {
        string path = AssetPath(f.path); BitmapSource bitmap;
        if (frameCache.TryGetValue(path, out bitmap)) {
            int index = frameOrder.FindIndex(p => String.Equals(p, path, StringComparison.OrdinalIgnoreCase));
            if (index >= 0) frameOrder.RemoveAt(index);
            frameOrder.Add(path); return bitmap;
        }
        var frameClock = Stopwatch.StartNew();
        var b = new BitmapImage();
        b.BeginInit(); b.CacheOption = BitmapCacheOption.OnLoad; b.UriSource = new Uri(path); b.EndInit(); b.Freeze();
        Require(b.PixelWidth == manifest.canvas.width && b.PixelHeight == manifest.canvas.height, "帧尺寸与画布不一致：" + f.path);
        var converted = new FormatConvertedBitmap(b, PixelFormats.Bgra32, null, 0); converted.Freeze();
        if (decodeScratch == null) decodeScratch = new byte[manifest.canvas.width * manifest.canvas.height * 4];
        converted.CopyPixels(decodeScratch, manifest.canvas.width * 4, 0);
        bitmap = converted; frameCache.Add(path, bitmap); frameOrder.Add(path);
        if (frameOrder.Count > FrameCacheLimit) {
            frameCache.Remove(frameOrder[0]); frameOrder.RemoveAt(0);
            if (++evictionsSinceCollection >= 8) { GC.Collect(); GC.WaitForPendingFinalizers(); evictionsSinceCollection = 0; }
        }
        maxCachedFrames = Math.Max(maxCachedFrames, frameCache.Count);
        slowestFrameDecodeMs = Math.Max(slowestFrameDecodeMs, frameClock.ElapsedMilliseconds);
        return bitmap;
    }
    static byte[] CopyFramePixels(BitmapSource bitmap) {
        var data = new byte[bitmap.PixelWidth * bitmap.PixelHeight * 4];
        bitmap.CopyPixels(data, bitmap.PixelWidth * 4, 0); return data;
    }
    static void Load() {
        string path = Path.Combine(Root, "action-manifest.json");
        Require(new FileInfo(path).Length <= 1024 * 1024, "清单超过 1MB。");
        manifest = Json.Deserialize<Manifest>(File.ReadAllText(path)); Validate(manifest, true);
        playback = new Playback(manifest); settings = new Settings();
        string config = Path.Combine(Root, "config.json");
        if (File.Exists(config)) {
            settings = Json.Deserialize<Settings>(File.ReadAllText(config));
            Require(settings != null, "配置无效。");
            if (settings.scale == .75) settings.scale = 1;
            Require(settings.scale == 1 || settings.scale == 1.25 || settings.scale == 1.5 || settings.scale == 2, "配置缩放无效。");
            settings.hotkeys = NormalizeBindings(settings.hotkeys);
            Require((!settings.left.HasValue || Finite(settings.left.Value)) && (!settings.top.HasValue || Finite(settings.top.Value)), "配置位置无效。");
        }
    }
    static void WriteAtomic(string path, string content) {
        string temp = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try {
            File.WriteAllText(temp, content, new System.Text.UTF8Encoding(false));
            if (File.Exists(path)) File.Replace(temp, path, null); else File.Move(temp, path);
        } finally { if (File.Exists(temp)) File.Delete(temp); }
    }
    static void Save() {
        settings.left = window.Left; settings.top = window.Top;
        WriteAtomic(Path.Combine(Root, "config.json"), Json.Serialize(settings));
        Trace("config_saved");
    }
    static void Log(Exception ex) {
        try { File.AppendAllText(Path.Combine(Root, "error.log"), DateTime.Now.ToString("s") + " " + ex + Environment.NewLine); } catch { }
    }
    static void Trace(string name) {
        if (!diagnostics) return;
        events.Add(new { name = name, timeMs = Clock.ElapsedMilliseconds, action = playback.current.id,
            left = window.Left, top = window.Top, scale = settings.scale, dragging = dragging,
            workingSetBytes = Process.GetCurrentProcess().WorkingSet64, peakWorkingSetBytes = Process.GetCurrentProcess().PeakWorkingSet64,
            cachedFrames = frameCache.Count, slowestFrameDecodeMs = slowestFrameDecodeMs });
        if (events.Count > 200) events.RemoveAt(0);
        WriteAtomic(Path.Combine(Root, "diagnostic.json"), Json.Serialize(events));
    }
    static bool Play(string id) {
        if (!playback.Available(id)) { Trace("unavailable_" + id); return false; }
        if (playback.current.id == "reach" && playback.Elapsed(Clock.ElapsedMilliseconds) < 5000) { Trace("locked_" + id); return false; }
        var next = playback.actions[id];
        var decodeClock = Stopwatch.StartNew();
        FrameBitmap(next.frames[0]); if (next.effects.Length > 0) FrameBitmap(next.effects[0]);
        bool accepted = playback.Select(id, Clock.ElapsedMilliseconds);
        if (accepted) { hitBitmap = null; hitPixels = null; Draw(); Trace("play_" + id + "_decode_ms_" + decodeClock.ElapsedMilliseconds); }
        else Trace("locked_" + id);
        return accepted;
    }
    static bool AlphaAt(byte[] pixels, int width, int height, double x, double y) {
        int ix = (int)Math.Floor(x), iy = (int)Math.Floor(y);
        return ix >= 0 && iy >= 0 && ix < width && iy < height && pixels[(iy * width + ix) * 4 + 3] >= 16;
    }
    static bool CharacterAt(Point p) {
        var a = playback.current;
        if (a.frames.Length == 0) return p.X >= 224 && p.X < 544 && p.Y >= 430 && p.Y < 704;
        int frame = Playback.FrameAt(a.frames, playback.Elapsed(Clock.ElapsedMilliseconds), a.loop);
        BitmapSource bitmap = FrameBitmap(a.frames[frame]);
        if (bitmap != hitBitmap) { hitPixels = CopyFramePixels(bitmap); hitBitmap = bitmap; }
        return AlphaAt(hitPixels, manifest.canvas.width, manifest.canvas.height, p.X, p.Y);
    }
    static void Resize(double scale) {
        double oldFactor = settings.scale * .5;
        double footX = window.Left + manifest.anchor.x * oldFactor, footY = window.Top + manifest.anchor.y * oldFactor;
        settings.scale = scale;
        window.Width = manifest.canvas.width * .5 * scale; window.Height = manifest.canvas.height * .5 * scale;
        window.Left = footX - manifest.anchor.x * .5 * scale; window.Top = footY - manifest.anchor.y * .5 * scale;
    }
    static void KeepVisible() {
        double left = SystemParameters.VirtualScreenLeft, top = SystemParameters.VirtualScreenTop;
        window.Left = Math.Max(left - window.Width + 100, Math.Min(left + SystemParameters.VirtualScreenWidth - 100, window.Left));
        window.Top = Math.Max(top - window.Height + 100, Math.Min(top + SystemParameters.VirtualScreenHeight - 100, window.Top));
    }
    static MenuItem AddItem(string label, Action action) {
        var item = new MenuItem { Header = label }; item.Click += (s, e) => action(); menu.Items.Add(item); return item;
    }
    static void BuildMenu() {
        menu = new ContextMenu(); actionItems = new List<MenuItem>();
        for (int i = 0; i < Ids.Length; i++) {
            string id = Ids[i]; var a = playback.actions[id];
            if (playback.Available(id)) actionItems.Add(AddItem(a.label, () => Play(id)));
        }
        menu.Items.Add(new Separator());
        if (playback.Available("remember")) {
            var auto = new MenuItem { Header = "自动随机动作（每5秒）", IsCheckable = true, IsChecked = settings.autoRandom };
            menu.Items.Add(auto);
            auto.Click += (s, e) => {
                bool old = settings.autoRandom; settings.autoRandom = auto.IsChecked;
                try { Save(); } catch (Exception ex) { settings.autoRandom = old; auto.IsChecked = old; Log(ex); MessageBox.Show("设置未保存：" + ex.Message); }
            };
        }
        foreach (double value in new[] { 1.0, 1.25, 1.5, 2.0 }) {
            double scale = value;
            AddItem("显示大小 " + (int)(value * 100) + "%", () => {
                double old = settings.scale;
                try { Resize(scale); Save(); } catch (Exception ex) { Resize(old); Log(ex); MessageBox.Show("设置未保存：" + ex.Message); }
            });
        }
        AddItem("快捷键设置…", EditShortcuts);
        AddItem("关于与素材状态", () => MessageBox.Show(window,
            "老鲁迪桌宠 v0.3\n" + String.Join("\n", manifest.actions.Select(a => a.label + "：" + (playback.Available(a.id) ? "可用" : "尚未完成"))) +
            "\n\n拖动移动；右键选择可用动作或退出。\n最后五秒伸手完整播放后返回待机，期间允许拖动。", "老鲁迪桌宠"));
        AddItem("退出", () => window.Close());
        menu.Opened += (s, e) => {
            pressed = false;
            if (canvas.IsMouseCaptured) canvas.ReleaseMouseCapture();
            bool locked = playback.current.id == "reach" && playback.Elapsed(Clock.ElapsedMilliseconds) < 5000;
            foreach (var item in actionItems) item.IsEnabled = !locked;
            Trace("menu_open");
        };
        menu.Closed += (s, e) => { Trace("menu_closed"); };
    }
    static void ScheduleRandom() { nextRandom = Clock.ElapsedMilliseconds + 5000; }
    static bool CanRandom(long now) {
        return RandomEligible(settings.autoRandom, playback.current.id, pressed || dragging || menu.IsOpen || editingHotkeys);
    }
    static bool RandomEligible(bool enabled, string action, bool busy) {
        return enabled && !busy && (action == "idle" || action == "seated_idle");
    }
    static void RandomTick(long now) {
        if (now < nextRandom) return;
        nextRandom += ((now - nextRandom) / 5000 + 1) * 5000;
        if (!CanRandom(now)) { Trace("random_skipped_busy"); return; }
        string[] available = RandomIds.Where(id => playback.Available(id)).ToArray();
        if (available.Length > 0) { string chosen = available[Random.Next(available.Length)]; Trace("random_chosen_" + chosen); Play(chosen); }
    }
    static bool SeatedAction(string id) { return id == "time_return" || id == "seated_idle"; }
    static string ReachPhase(long elapsed) {
        if (elapsed < 1000) return "认出 · 0—1秒";
        if (elapsed < 3000) return "缓慢前伸 · 1—3秒";
        if (elapsed < 4000) return "指尖颤抖、停留 · 3—4秒";
        return "落空、手垂 · 4—5秒";
    }
    static void Draw() {
        var a = playback.current; long elapsed = playback.Elapsed(Clock.ElapsedMilliseconds);
        int f = Playback.FrameAt(a.frames, elapsed, a.loop), fx = Playback.FrameAt(a.effects, elapsed, a.loop);
        shownAction = a.id; shownFrame = f;
        character.Source = f < 0 ? null : FrameBitmap(a.frames[f]);
        effects.Source = fx < 0 ? null : FrameBitmap(a.effects[fx]);
        placeholder.Visibility = f < 0 ? Visibility.Visible : Visibility.Collapsed;
        badge.Visibility = a.placeholder && f >= 0 ? Visibility.Visible : Visibility.Collapsed;
        title.Text = f < 0 ? "老鲁迪\n素材占位" : "";
        detail.Text = f < 0 ? a.label + "\n" + (a.id == "reach" ? ReachPhase(elapsed) : "等待设计帧包") + "\n右键选择动作 · 拖动移动" : "";
        badgeText.Text = a.placeholder && f >= 0 ? "素材占位 · 未完成动画" : "";
        // The placeholder is a label only: no substitute character or fake animation.
    }
    static void EndDrag() {
        pressed = false; dragging = false;
        if (canvas.IsMouseCaptured) canvas.ReleaseMouseCapture();
    }
    static void BuildWindow() {
        Require(playback.Available(playback.current.id) && (playback.current.id == "idle" || playback.current.id == "seated_idle"), "没有可用的站姿或坐姿待机素材。");
        window = new Window { Title = "老鲁迪桌宠 v0.3", WindowStyle = WindowStyle.None, AllowsTransparency = true,
            Background = Brushes.Transparent, Topmost = true, ShowInTaskbar = true, ResizeMode = ResizeMode.NoResize,
            Width = manifest.canvas.width * .5 * settings.scale, Height = manifest.canvas.height * .5 * settings.scale };
        InputMethod.SetIsInputMethodEnabled(window, false);
        InputMethod.SetIsInputMethodSuspended(window, true);
        window.Left = settings.left ?? SystemParameters.WorkArea.Right - window.Width - 24;
        window.Top = settings.top ?? SystemParameters.WorkArea.Bottom - window.Height - 24;
        KeepVisible();
        canvas = new Canvas { Width = manifest.canvas.width, Height = manifest.canvas.height, Background = Brushes.Transparent };
        var viewbox = new Viewbox { Child = canvas, Stretch = Stretch.Fill }; window.Content = viewbox;
        character = new Image { Width = manifest.canvas.width, Height = manifest.canvas.height, IsHitTestVisible = false };
        effects = new Image { Width = manifest.canvas.width, Height = manifest.canvas.height, IsHitTestVisible = false };
        RenderOptions.SetBitmapScalingMode(character, BitmapScalingMode.HighQuality);
        RenderOptions.SetBitmapScalingMode(effects, BitmapScalingMode.HighQuality);
        title = new TextBlock { FontSize = 36, FontWeight = FontWeights.SemiBold, Foreground = Brushes.White, TextAlignment = TextAlignment.Center };
        detail = new TextBlock { FontSize = 21, Foreground = Brushes.LightGray, TextAlignment = TextAlignment.Center, Margin = new Thickness(0, 18, 0, 0), TextWrapping = TextWrapping.Wrap };
        var text = new StackPanel { VerticalAlignment = VerticalAlignment.Center }; text.Children.Add(title); text.Children.Add(detail);
        placeholder = new Border { Width = 320, Height = 274, CornerRadius = new CornerRadius(16), Background = new SolidColorBrush(Color.FromRgb(39, 39, 50)), BorderBrush = Brushes.SlateGray, BorderThickness = new Thickness(2), Padding = new Thickness(10), Child = text, IsHitTestVisible = false };
        Canvas.SetLeft(placeholder, 224); Canvas.SetTop(placeholder, 430);
        badgeText = new TextBlock { FontSize = 22, Foreground = Brushes.White };
        badge = new Border { Background = Brushes.DarkSlateGray, Padding = new Thickness(8), Child = badgeText, IsHitTestVisible = false };
        Canvas.SetLeft(badge, 250); Canvas.SetTop(badge, 720);
        canvas.Children.Add(character); canvas.Children.Add(effects); canvas.Children.Add(placeholder); canvas.Children.Add(badge);
        BuildMenu();
        canvas.MouseLeftButtonDown += (s, e) => {
            if (!CharacterAt(e.GetPosition(canvas))) return;
            downScreen = lastScreen = canvas.PointToScreen(e.GetPosition(canvas)); pressed = true; canvas.CaptureMouse(); e.Handled = true;
        };
        canvas.MouseMove += (s, e) => {
            if (!pressed || e.LeftButton != MouseButtonState.Pressed) return;
            Point screen = canvas.PointToScreen(e.GetPosition(canvas));
            Vector delta = screen - lastScreen;
            if (!dragging && (screen - downScreen).Length >= 4) {
                dragging = true; Trace("drag_begin");
            }
            if (dragging) {
                var transform = source.CompositionTarget.TransformFromDevice;
                Vector move = transform.Transform(delta); window.Left += move.X; window.Top += move.Y;
                if (Clock.ElapsedMilliseconds - lastTrace > 200) { lastTrace = Clock.ElapsedMilliseconds; Trace("drag_move"); }
            }
            lastScreen = screen; e.Handled = true;
        };
        canvas.MouseLeftButtonUp += (s, e) => {
            bool click = pressed && !dragging && CharacterAt(e.GetPosition(canvas)); bool wasDrag = dragging;
            EndDrag(); if (wasDrag) { KeepVisible(); Trace("drag_end"); }
            if (click && !SeatedAction(playback.current.id)) {
                if (!playback.Available("warning")) MessageBox.Show(window, "这个动作还没有准备好，当前状态会保持。", "动作暂不可用");
                else Play("warning");
            }
            e.Handled = true;
        };
        canvas.LostMouseCapture += (s, e) => { if (pressed) EndDrag(); };
        canvas.MouseRightButtonUp += (s, e) => {
            if (!CharacterAt(e.GetPosition(canvas))) return;
            EndDrag(); menu.PlacementTarget = canvas; menu.IsOpen = true; e.Handled = true;
        };
        window.SourceInitialized += (s, e) => {
            source = HwndSource.FromHwnd(new WindowInteropHelper(window).Handle); source.AddHook(Hook);
            if (!smoke) { string error = RegisterBindings(settings.hotkeys); if (error.Length > 0) MessageBox.Show(window, "以下快捷键注册失败：\n" + error, "快捷键冲突"); }
        };
        window.Closing += (s, e) => {
            if (!smoke) { try { Save(); } catch (Exception ex) { Log(ex); MessageBox.Show(window, "配置未能保存，原配置仍保留：" + ex.Message); } }
        };
        window.Closed += (s, e) => { UnregisterBindings(); timer.Stop(); Trace("closed"); };
        window.ContentRendered += (s, e) => {
            Trace("ready");
            if (smoke) {
                double x = window.Left + manifest.anchor.x * .5 * settings.scale;
                double y = window.Top + manifest.anchor.y * .5 * settings.scale;
                double old = settings.scale; foreach (double size in new[] { 1.0, 1.25, 1.5, 2.0 }) { Resize(size); Require(Math.Abs(x - window.Left - manifest.anchor.x * .5 * settings.scale) < .01 && Math.Abs(y - window.Top - manifest.anchor.y * .5 * settings.scale) < .01, "缩放脚底锚点移动。"); } Resize(old);
                Require(Math.Abs(x - window.Left - manifest.anchor.x * .5 * settings.scale) < .01 && Math.Abs(y - window.Top - manifest.anchor.y * .5 * settings.scale) < .01, "缩放脚底锚点移动。");
                if (smokeAll) {
                    allLeft = window.Left; allTop = window.Top; allWidth = window.Width; allHeight = window.Height;
                    foreach (string id in Ids) { if (playback.Available(id)) allQueue.Add(id); else allSkipped.Add(id); }
                    StartNextAllAction(); return;
                }
                string testAction = smokeTime ? "time_return" : smokeIdle ? "idle" : smokeSeat ? "seated_idle" : "reach";
                if (!playback.Available(testAction)) {
                    WriteAtomic(Path.Combine(Root, SmokeReportName()), Json.Serialize(new { passed = false, skipped = true, reason = "动作或结束待机尚未完成：" + testAction }));
                    window.Close(); return;
                }
                Require(Play(testAction), "测试动作无法启动。"); smokeStarted = playback.started;
            }
        };
        timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(16) };
        timer.Tick += (s, e) => {
            long now = Clock.ElapsedMilliseconds; string before = playback.current.id;
            playback.Advance(now); if (before != playback.current.id) Trace("finished_" + before);
            Draw();
            if (!smoke) RandomTick(now);
            if (smokeAll && smokeStarted > 0) { CheckAllAction(Clock.ElapsedMilliseconds); return; }
            if (smoke && smokeStarted > 0) {
                if (smokeTime && !timePreviewSaved && now - smokeStarted >= 1000) {
                    Require(playback.current.id == "time_return", "预览捕获过晚，未捕获穿越归来状态。");
                    SavePreview("time-return-preview.png"); timePreviewSaved = true;
                    Require(!CanRandom(now), "time_return 不应参与随机调度。");
                }
                if (!smokeTime && !smokeIdle && !smokeSeat && !smokeLockChecked && now - smokeStarted >= 1000) { Require(!Play("idle"), "reach 被其他动作中断。"); smokeLockChecked = true; }
                string cycleId = smokeIdle ? "idle" : "seated_idle";
                if ((smokeIdle || smokeSeat) && now - smokeStarted >= playback.actions[cycleId].durationMs + 100) {
                    var cycle = playback.actions[cycleId];
                    Require(playback.current.id == cycleId && window.IsVisible && source != null &&
                        Playback.FrameAt(cycle.frames, cycle.durationMs - 1, true) == cycle.frames.Length - 1 &&
                        Playback.FrameAt(cycle.frames, cycle.durationMs, true) == 0, "待机循环检查失败：" + cycleId);
                    SavePreview(smokeIdle ? "idle-preview.png" : "seated-idle-preview.png");
                    WriteAtomic(Path.Combine(Root, SmokeReportName()), Json.Serialize(new {
                        passed = true, elapsedMs = now - smokeStarted, cycleMs = cycle.durationMs,
                        finalAction = playback.current.id, frames = cycle.frames.Length, cycleBoundaryPassed = true
                    }));
                    window.Close();
                }
                if (smokeTime && now - smokeStarted >= playback.actions["time_return"].durationMs + 100) {
                    Require(timePreviewSaved && playback.current.id == "seated_idle" && CanRandom(now) && window.IsVisible && source != null, "穿越归来未保持坐姿。");
                    SavePreview("seated-idle-preview.png");
                    var from = playback.actions["time_return"].frames;
                    var to = playback.actions["seated_idle"].frames;
                    bool? matching = from.Length == 0 || to.Length == 0 ? (bool?)null : CopyFramePixels(FrameBitmap(from[from.Length - 1])).SequenceEqual(CopyFramePixels(FrameBitmap(to[0])));
                    WriteAtomic(Path.Combine(Root, "time-return-smoke-report.json"), Json.Serialize(new {
                        passed = true, elapsedMs = now - smokeStarted, finalAction = playback.current.id, seatedRandomEligible = true,
                        effectsIndependent = canvas.Children.IndexOf(effects) > canvas.Children.IndexOf(character) && !effects.IsHitTestVisible,
                        timeReturnFrames = from.Length, seatedFrames = to.Length, effectFrames = playback.actions["time_return"].effects.Length,
                        transitionPixelsIdentical = matching, placeholder = playback.actions["time_return"].placeholder || playback.actions["seated_idle"].placeholder
                    }));
                    window.Close();
                } else if (!smokeTime && !smokeIdle && !smokeSeat && now - smokeStarted >= 5100) {
                    Require(playback.current.id == "idle" && smokeLockChecked && window.IsVisible && source != null, "窗口或 reach 回待机检查失败。");
                    var screenshot = new RenderTargetBitmap(manifest.canvas.width, manifest.canvas.height, 96, 96, PixelFormats.Pbgra32);
                    screenshot.Render(canvas); var png = new PngBitmapEncoder(); png.Frames.Add(BitmapFrame.Create(screenshot));
                    using (var stream = File.Create(Path.Combine(Root, "smoke-window.png"))) png.Save(stream);
                    WriteAtomic(Path.Combine(Root, "smoke-report.json"), Json.Serialize(new {
                        passed = true, reachLocked = smokeLockChecked, elapsedMs = now - smokeStarted,
                        finalAction = playback.current.id, anchorPreserved = true, windowShown = true,
                        effectsIndependent = canvas.Children.IndexOf(effects) > canvas.Children.IndexOf(character) && !effects.IsHitTestVisible,
                        placeholderActions = manifest.actions.Where(a => a.placeholder).Select(a => a.id).ToArray()
                    }));
                    window.Close();
                }
            }
        };
        ScheduleRandom(); Draw(); timer.Start();
    }
    static string SmokeReportName() { return smokeAll ? "all-smoke-report.json" : smokeTime ? "time-return-smoke-report.json" : smokeIdle ? "idle-smoke-report.json" : smokeSeat ? "seated-smoke-report.json" : "smoke-report.json"; }
    static void StartNextAllAction() {
        if (allIndex >= allQueue.Count) {
            WriteAtomic(Path.Combine(Root, SmokeReportName()), Json.Serialize(new {
                passed = true, complete = allSkipped.Count == 0 && allFramesCovered, checkedActions = allResults.ToArray(), skippedActions = allSkipped.ToArray(),
                peakWorkingSetBytes = Process.GetCurrentProcess().PeakWorkingSet64, slowestFrameDecodeMs = slowestFrameDecodeMs,
                maxCachedFrames = maxCachedFrames, windowAnchorPreserved = true
            }));
            window.Close(); return;
        }
        string id = allQueue[allIndex]; allCaptured = false; allCaptureMs = 0; allObservedFrames.Clear();
        Require(Play(id), "逐动作检查无法启动：" + id); smokeStarted = playback.started;
    }
    static bool HasVisibleAlpha(BitmapSource bitmap) {
        if (bitmap == null) return false;
        byte[] bytes = CopyFramePixels(bitmap);
        for (int i = 3; i < bytes.Length; i += 4) if (bytes[i] >= 16) return true;
        return false;
    }
    static void SaveCheckedPreview(string name) {
        Require(HasVisibleAlpha(character.Source as BitmapSource), "角色帧为空。");
        var rendered = new RenderTargetBitmap(manifest.canvas.width, manifest.canvas.height, 96, 96, PixelFormats.Pbgra32);
        rendered.Render(canvas); Require(HasVisibleAlpha(rendered), "渲染画布为空。");
        var png = new PngBitmapEncoder(); png.Frames.Add(BitmapFrame.Create(rendered));
        using (var stream = File.Create(Path.Combine(Root, name))) png.Save(stream);
    }
    static void CheckRenderedFrame() {
        Require(HasVisibleAlpha(character.Source as BitmapSource), "角色帧为空。");
        var rendered = new RenderTargetBitmap(manifest.canvas.width, manifest.canvas.height, 96, 96, PixelFormats.Pbgra32);
        rendered.Render(canvas); Require(HasVisibleAlpha(rendered), "渲染画布为空。");
    }
    static void CheckAllAction(long now) {
        string id = allQueue[allIndex]; var action = playback.actions[id]; long elapsed = now - smokeStarted;
        Require(window.IsVisible && source != null && Math.Abs(window.Left - allLeft) < .01 && Math.Abs(window.Top - allTop) < .01 &&
            Math.Abs(window.Width - allWidth) < .01 && Math.Abs(window.Height - allHeight) < .01, "窗口或锚点发生移动：" + id);
        if (shownAction == id && shownFrame >= 0 && allObservedFrames.Add(shownFrame)) CheckRenderedFrame();
        if (!allCaptured && elapsed >= action.durationMs / 2) {
            Require(playback.current.id == id, "错过动作中途截图：" + id);
            SaveCheckedPreview("smoke-all-" + id + ".png"); allCaptured = true; allCaptureMs = elapsed;
        }
        if (elapsed < action.durationMs + 60) return;
        Require(allCaptured, "未捕获动作截图：" + id);
        string expected = action.loop ? id : action.next;
        Require(playback.current.id == expected, "动作结束状态错误：" + id);
        if (id == "time_return") {
            var seated = playback.actions["seated_idle"];
            Require(CopyFramePixels(FrameBitmap(action.frames[action.frames.Length - 1])).SequenceEqual(CopyFramePixels(FrameBitmap(seated.frames[0]))), "穿越归来与坐姿交接帧不一致。");
            if (action.effects.Length > 0) {
                byte[] lastEffect = CopyFramePixels(FrameBitmap(action.effects[action.effects.Length - 1]));
                for (int i = 3; i < lastEffect.Length; i += 4) Require(lastEffect[i] == 0, "时钟特效末帧未完全消散。");
            }
        }
        if (action.loop) Require(Playback.FrameAt(action.frames, action.durationMs - 1, true) == action.frames.Length - 1 &&
            Playback.FrameAt(action.frames, action.durationMs, true) == 0, "循环边界错误：" + id);
        int[] missing = Enumerable.Range(0, action.frames.Length).Where(i => !allObservedFrames.Contains(i)).ToArray();
        if (missing.Length > 0) allFramesCovered = false;
        allResults.Add(new { id = id, durationMs = action.durationMs, elapsedMs = elapsed, loop = action.loop,
            finalAction = playback.current.id, renderedFrameEntries = allObservedFrames.Count, frameEntries = action.frames.Length,
            unobservedFrames = missing, screenshot = "smoke-all-" + id + ".png", screenshotMs = allCaptureMs });
        allIndex++; StartNextAllAction();
    }
    static void SavePreview(string name) {
        var screenshot = new RenderTargetBitmap(manifest.canvas.width, manifest.canvas.height, 96, 96, PixelFormats.Pbgra32);
        screenshot.Render(canvas); var png = new PngBitmapEncoder(); png.Frames.Add(BitmapFrame.Create(screenshot));
        using (var stream = File.Create(Path.Combine(Root, name))) png.Save(stream);
    }
    static IntPtr Hook(IntPtr hwnd, int message, IntPtr wp, IntPtr lp, ref bool handled) {
        if (message == 0x0312 && !editingHotkeys) { int i = wp.ToInt32() - 1; if (i >= 0 && i < Ids.Length) Play(Ids[i]); handled = true; return IntPtr.Zero; }
        if (message == 0x84 && !pressed && source != null) { // WM_NCHITTEST; layered alpha also gives native pass-through at fully clear pixels.
            long value = lp.ToInt64();
            var screen = new Point(unchecked((short)(value & 0xffff)), unchecked((short)((value >> 16) & 0xffff)));
            if (!CharacterAt(canvas.PointFromScreen(screen))) { handled = true; return new IntPtr(-1); }
        }
        return IntPtr.Zero;
    }
    [DllImport("user32.dll", SetLastError = true)] static extern bool RegisterHotKey(IntPtr hWnd, int id, uint modifiers, uint key);
    [DllImport("user32.dll", SetLastError = true)] static extern bool UnregisterHotKey(IntPtr hWnd, int id);
    static bool editingHotkeys;
    const uint NoRepeat = 0x4000;
    static void ParseShortcut(string text, out uint mods, out uint vk) {
        mods = 0; vk = 0;
        string[] parts = text.Split('+');
        Require(parts.Length >= 2, "快捷键须含修饰键和一个普通键。");
        for (int i = 0; i < parts.Length - 1; i++) {
            uint bit;
            switch (parts[i].Trim().ToLowerInvariant()) {
                case "ctrl": case "control": bit = 2; break;
                case "alt": bit = 1; break;
                case "shift": bit = 4; break;
                case "win": case "windows": bit = 8; break;
                default: throw new ArgumentException("无效修饰键：" + parts[i]);
            }
            Require((mods & bit) == 0, "重复的修饰键。"); mods |= bit;
        }
        Require((mods & 3) != 0, "快捷键必须包含 Ctrl 或 Alt。");
        string k = parts[parts.Length - 1].Trim(); Key key;
        if (k.Length == 1 && k[0] >= '0' && k[0] <= '9') k = "D" + k;
        Require(Enum.TryParse<Key>(k, true, out key), "无效按键：" + k);
        vk = (uint)KeyInterop.VirtualKeyFromKey(key);
        Require(vk != 0 && key != Key.Tab && key != Key.Escape && key != Key.System &&
            key != Key.LeftCtrl && key != Key.RightCtrl && key != Key.LeftAlt && key != Key.RightAlt &&
            key != Key.LeftShift && key != Key.RightShift && key != Key.LWin && key != Key.RWin,
            "请使用 Tab、Escape 和修饰键以外的主键。");
    }
    static string FormatShortcut(uint mods, uint vk) {
        var names = new List<string>();
        if ((mods & 2) != 0) names.Add("Ctrl"); if ((mods & 1) != 0) names.Add("Alt");
        if ((mods & 4) != 0) names.Add("Shift"); if ((mods & 8) != 0) names.Add("Win");
        Key key = KeyInterop.KeyFromVirtualKey((int)vk); string name = key.ToString();
        if (key >= Key.D0 && key <= Key.D9) name = ((int)(key - Key.D0)).ToString();
        names.Add(name); return String.Join("+", names.ToArray());
    }
    static Dictionary<string, string> NormalizeBindings(Dictionary<string, string> bindings) {
        var result = new Dictionary<string, string>(); var seen = new HashSet<string>();
        foreach (var pair in bindings ?? new Dictionary<string, string>()) {
            Require(Ids.Contains(pair.Key), "未知快捷键动作：" + pair.Key);
            if (String.IsNullOrWhiteSpace(pair.Value)) continue;
            uint mods, vk; ParseShortcut(pair.Value, out mods, out vk);
            Require(seen.Add(mods + ":" + vk), "快捷键重复：" + FormatShortcut(mods, vk));
            result[pair.Key] = FormatShortcut(mods, vk);
        }
        return result;
    }
    static void UnregisterBindings() {
        if (source != null) for (int i = 0; i < Ids.Length; i++) UnregisterHotKey(source.Handle, i + 1);
    }
    static string RegisterBindings(Dictionary<string, string> bindings) {
        UnregisterBindings(); var errors = new List<string>();
        foreach (var pair in bindings) {
            uint mods, vk; ParseShortcut(pair.Value, out mods, out vk);
            int index = Array.IndexOf(Ids, pair.Key);
            if (!RegisterHotKey(source.Handle, index + 1, mods | NoRepeat, vk))
                errors.Add(playback.actions[pair.Key].label + "（" + pair.Value + "）被系统或其他程序占用");
        }
        return String.Join("\n", errors.ToArray());
    }
    static void EditShortcuts() {
        editingHotkeys = true; UnregisterBindings();
        var original = new Dictionary<string, string>(settings.hotkeys);
        try {
            var dialog = new Window { Title = "快捷键设置", Owner = window, WindowStartupLocation = WindowStartupLocation.CenterOwner,
                Width = 510, Height = 620, MinWidth = 460, MinHeight = 540, ShowInTaskbar = false, ResizeMode = ResizeMode.CanResize };
            var root = new DockPanel { Margin = new Thickness(14) }; dialog.Content = root;
            var bottom = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right, Margin = new Thickness(0, 10, 0, 0) };
            DockPanel.SetDock(bottom, Dock.Bottom); root.Children.Add(bottom);
            var scroll = new ScrollViewer { VerticalScrollBarVisibility = ScrollBarVisibility.Auto }; root.Children.Add(scroll);
            var rows = new StackPanel(); scroll.Content = rows;
            rows.Children.Add(new TextBlock { Text = "选中输入框后按包含 Ctrl 或 Alt 的组合键。Tab / Shift+Tab 切换，Esc 取消。", TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 10) });
            var boxes = new Dictionary<string, TextBox>();
            foreach (string id in Ids) {
                string actionId = id; var row = new DockPanel { Margin = new Thickness(0, 4, 0, 4) };
                var label = new TextBlock { Text = playback.actions[id].label, Width = 150, VerticalAlignment = VerticalAlignment.Center };
                DockPanel.SetDock(label, Dock.Left); row.Children.Add(label);
                var clear = new Button { Content = "清除", Width = 55, Margin = new Thickness(6, 0, 0, 0) };
                DockPanel.SetDock(clear, Dock.Right); row.Children.Add(clear);
                string value; original.TryGetValue(id, out value);
                var box = new TextBox { Text = value ?? "", IsReadOnly = true, MinHeight = 28, VerticalContentAlignment = VerticalAlignment.Center };
                boxes[actionId] = box; row.Children.Add(box); clear.Click += (s, e) => box.Text = "";
                box.PreviewKeyDown += (s, e) => {
                    Key key = e.Key == Key.System ? e.SystemKey : e.Key;
                    if (key == Key.Tab || key == Key.Escape || (key == Key.Enter && (Keyboard.Modifiers & (ModifierKeys.Control | ModifierKeys.Alt)) == 0)) return;
                    e.Handled = true;
                    if (key == Key.LeftCtrl || key == Key.RightCtrl || key == Key.LeftAlt || key == Key.RightAlt ||
                        key == Key.LeftShift || key == Key.RightShift || key == Key.LWin || key == Key.RWin) return;
                    uint mods = 0; var m = Keyboard.Modifiers;
                    if ((m & ModifierKeys.Control) != 0) mods |= 2; if ((m & ModifierKeys.Alt) != 0) mods |= 1;
                    if ((m & ModifierKeys.Shift) != 0) mods |= 4; if ((m & ModifierKeys.Windows) != 0) mods |= 8;
                    uint vk = (uint)KeyInterop.VirtualKeyFromKey(key);
                    if ((mods & 3) != 0 && vk != 0) box.Text = FormatShortcut(mods, vk);
                };
                rows.Children.Add(row);
            }
            var recommended = new Button { Content = "填入推荐", Margin = new Thickness(0, 0, 6, 0), Padding = new Thickness(8, 4, 8, 4) };
            var clearAll = new Button { Content = "清空全部", Margin = new Thickness(0, 0, 6, 0), Padding = new Thickness(8, 4, 8, 4) };
            var save = new Button { Content = "保存", IsDefault = true, Margin = new Thickness(0, 0, 6, 0), Padding = new Thickness(12, 4, 12, 4) };
            var cancel = new Button { Content = "取消", IsCancel = true, Padding = new Thickness(12, 4, 12, 4) };
            bottom.Children.Add(recommended); bottom.Children.Add(clearAll); bottom.Children.Add(save); bottom.Children.Add(cancel);
            recommended.Click += (s, e) => { for (int i = 0; i < Ids.Length; i++) boxes[Ids[i]].Text = "Ctrl+Alt+" + (i + 1); };
            clearAll.Click += (s, e) => { foreach (var box in boxes.Values) box.Text = ""; };
            save.Click += (s, e) => {
                try {
                    var proposed = NormalizeBindings(boxes.ToDictionary(p => p.Key, p => p.Value.Text));
                    string error = RegisterBindings(proposed);
                    if (error.Length > 0) { UnregisterBindings(); MessageBox.Show(dialog, "快捷键未保存：\n" + error, "快捷键冲突"); return; }
                    settings.hotkeys = proposed;
                    try { Save(); } catch { settings.hotkeys = original; UnregisterBindings(); throw; }
                    dialog.DialogResult = true;
                } catch (Exception ex) { Log(ex); MessageBox.Show(dialog, "快捷键未保存：" + ex.Message, "快捷键设置"); }
            };
            bool? saved = dialog.ShowDialog();
            if (saved != true) settings.hotkeys = original;
        } finally {
            editingHotkeys = false;
            string error = RegisterBindings(settings.hotkeys);
            if (error.Length > 0) MessageBox.Show(window, "以下快捷键未能恢复或注册：\n" + error, "快捷键冲突");
        }
    }

    static void Reject(Action work, string label) {
        bool rejected = false; try { work(); } catch (Exception ex) { if (ex is InvalidDataException || ex is ArgumentException) rejected = true; else throw; }
        Require(rejected, "未拒绝无效输入：" + label);
    }
    static void SelfCheck() {
        var p = new Playback(manifest);
        var availableTest = Json.Deserialize<Manifest>(File.ReadAllText(Path.Combine(Root, "action-manifest.json")));
        foreach (var a in availableTest.actions) { a.placeholder = true; a.frames = new FrameSpec[0]; }
        var isolated = new Playback(availableTest);
        Require(!isolated.Available("idle") && !isolated.Available("seated_idle") && !isolated.Available("reach"), "占位动作不可展示。");
        var testSeat = availableTest.actions.Single(a => a.id == "seated_idle"); testSeat.placeholder = false; testSeat.frames = new[] { new FrameSpec { durationMs = 2400 } };
        isolated = new Playback(availableTest);
        Require(isolated.current.id == "seated_idle" && isolated.Available("seated_idle") && !isolated.Available("warning"), "坐姿优先或缺帧屏蔽失效。");
        var testReach = availableTest.actions.Single(a => a.id == "reach"); testReach.placeholder = false; testReach.frames = new[] { new FrameSpec { durationMs = 5000 } };
        Require(!isolated.Available("reach"), "缺少结束待机时不能播放 reach。");
        var testIdle = availableTest.actions.Single(a => a.id == "idle"); testIdle.placeholder = false; testIdle.frames = new[] { new FrameSpec { durationMs = 2400 } };
        Require(isolated.Available("reach"), "结束待机可用后 reach 应可播放。");
        testIdle.placeholder = true; Require(!isolated.Available("idle") && !isolated.Available("reach"), "有帧但占位的动作不能展示。");
        Require(p.Select("reach", 100), "reach 无法启动。");
        Require(!p.Select("grief", 1100) && !p.Select("idle", 5099) && !p.Select("reach", 2500), "reach 锁定失效。");
        p.Advance(5099); Require(p.current.id == "reach", "reach 提前结束。");
        p.Advance(5100); Require(p.current.id == "idle", "reach 未在 5000ms 返回 idle。");
        Require(p.Select("time_return", 6000), "time_return 无法启动。");
        long finish = 6000 + p.current.durationMs;
        p.Advance(finish - 1); Require(p.current.id == "time_return", "time_return 提前结束。");
        p.Advance(finish); Require(p.current.id == "seated_idle", "time_return 没有回到坐姿。");
        p.Advance(finish + 100000); Require(p.current.id == "seated_idle", "坐姿待机未保持。");
        Require(SeatedAction("time_return") && SeatedAction("seated_idle") && !SeatedAction("idle"), "坐姿交互状态错误。");
        Require(p.Select("warning", finish + 100001) && p.current.id == "warning", "无法手动切换坐姿。");
        var frames = new[] { new FrameSpec { durationMs = 1000 }, new FrameSpec { durationMs = 2000 }, new FrameSpec { durationMs = 1000 }, new FrameSpec { durationMs = 1000 } };
        Require(Playback.FrameAt(frames, 999, false) == 0 && Playback.FrameAt(frames, 1000, false) == 1 && Playback.FrameAt(frames, 3000, false) == 2 && Playback.FrameAt(frames, 4000, false) == 3 && Playback.FrameAt(frames, 5000, false) == 3 && Playback.FrameAt(frames, 5000, true) == 0, "帧时序边界失效。");
        byte[] pixels = new byte[16]; pixels[7] = 255; pixels[11] = 15; pixels[15] = 16;
        Require(!AlphaAt(pixels, 2, 2, 0, 0) && AlphaAt(pixels, 2, 2, 1, 0) && !AlphaAt(pixels, 2, 2, 0, 1) && AlphaAt(pixels, 2, 2, 1, 1) && !AlphaAt(pixels, 2, 2, -1, 1), "透明命中阈值失效。");
        var firstRealFrame = manifest.actions.SelectMany(a => a.frames.Concat(a.effects)).FirstOrDefault();
        if (firstRealFrame != null) {
            var sameDifferentCase = new FrameSpec { path = firstRealFrame.path.ToUpperInvariant() };
            Require(Object.ReferenceEquals(FrameBitmap(firstRealFrame), FrameBitmap(sameDifferentCase)) && frameCache.Count == 1 && frameOrder.Count == 1, "帧缓存没有合并相同路径的大小写变体。");
            frameCache.Clear(); frameOrder.Clear();
        }
        Reject(() => AssetPath("../escape.png"), "越界路径"); Reject(() => AssetPath("C:\\outside.png"), "绝对路径"); Reject(() => AssetPath("assets/frame.jpg"), "非 PNG");
        Func<Manifest> clone = () => Json.Deserialize<Manifest>(File.ReadAllText(Path.Combine(Root, "action-manifest.json")));
        var invalid = clone(); invalid.actions[1].id = "idle"; Reject(() => Validate(invalid, false), "重复动作");
        invalid = clone(); invalid.actions.Single(a => a.id == "reach").durationMs = 4999; Reject(() => Validate(invalid, false), "reach 非五秒");
        invalid = clone(); invalid.actions[0].placeholder = false; invalid.actions[0].frames = new FrameSpec[0]; Reject(() => Validate(invalid, false), "正式帧缺失");
        invalid = clone(); invalid.actions[0].frames = new[] { new FrameSpec { path = "assets/probe.png", durationMs = 1 } }; Reject(() => Validate(invalid, false), "帧时长错误");
        invalid = clone(); invalid.actions.Single(a => a.id == "time_return").next = "idle"; Reject(() => Validate(invalid, false), "穿越归来错误结束状态");
        invalid = clone(); invalid.actions.Single(a => a.id == "seated_idle").loop = false; Reject(() => Validate(invalid, false), "坐姿不循环");
        invalid = clone(); invalid.actions.Single(a => a.id == "time_return").durationMs = 4999; Reject(() => Validate(invalid, false), "穿越归来时长过短");
        invalid = clone(); invalid.actions.Single(a => a.id == "time_return").durationMs = 7001; Reject(() => Validate(invalid, false), "穿越归来时长过长");
        invalid = clone(); var seated = invalid.actions.Single(a => a.id == "seated_idle"); seated.effects = new[] { new FrameSpec { path = "assets/probe.png", durationMs = seated.durationMs } }; Reject(() => Validate(invalid, false), "坐姿残留时钟层");
        Require(RandomEligible(true, "idle", false) && RandomEligible(true, "seated_idle", false) && !RandomEligible(false, "idle", false) && !RandomEligible(true, "idle", true), "随机条件失效。");
        foreach (string id in RandomIds) Require(!RandomEligible(true, id, false), "忙碌动作被随机中断。");
        uint mods, vk; ParseShortcut("alt+CTRL+1", out mods, out vk); Require(FormatShortcut(mods, vk) == "Ctrl+Alt+1", "快捷键规范化失效。");
        Reject(() => NormalizeBindings(new Dictionary<string, string> { { "idle", "Ctrl+Alt+1" }, { "warning", "alt+ctrl+D1" } }), "重复快捷键");
        Reject(() => NormalizeBindings(new Dictionary<string, string> { { "idle", "Shift+A" } }), "快捷键缺少 Ctrl 或 Alt");
        Reject(() => NormalizeBindings(new Dictionary<string, string> { { "idle", "Win+A" } }), "快捷键缺少 Ctrl 或 Alt");
        Require(NormalizeBindings(null).Count == 0 && RandomIds.Length == 6, "默认快捷键或随机池错误。");
        WriteAtomic(Path.Combine(Root, "check-report.json"), Json.Serialize(new {
            passed = true, manifestValidated = true, actionCount = manifest.actions.Length, reachBoundaryMs = 5000,
            checks = new[] { "seated startup priority", "hide placeholder and empty frame actions", "require completed destination", "reach start/lock/replay/5000ms return", "time_return completion to persistent seated_idle", "manual action leaves seat", "seated drag and click classification", "time_return duration and next validation", "seated loop and effect validation", "frame boundaries and loop", "alpha threshold and bounds", "path traversal/absolute/extension rejection", "duplicate IDs", "reach duration", "missing production frames", "frame duration sum", "random when either idle, enabled and unoccupied; shortcut normalization and duplicates" },
            decodedCharacterFrames = manifest.actions.Sum(a => a.frames.Length), decodedEffectFrames = manifest.actions.Sum(a => a.effects.Length),
            completedAnimationClaims = manifest.actions.Where(a => !a.placeholder).Select(a => a.id).ToArray()
        }));
    }
    [STAThread] static int Main(string[] args) {
        smokeAll = args.Contains("--smoke-all"); smokeTime = args.Contains("--smoke-time"); smokeIdle = args.Contains("--smoke-idle"); smokeSeat = args.Contains("--smoke-seated"); smoke = args.Contains("--smoke") || smokeTime || smokeIdle || smokeSeat || smokeAll; diagnostics = args.Contains("--diagnostics");
        try {
            Load();
            if (args.Contains("--check")) { SelfCheck(); return 0; }
            bool created;
            using (var mutex = new Mutex(true, "Local\\OldRudyPetStandaloneV03", out created)) {
                if (!created) { if (!smoke) MessageBox.Show("老鲁迪桌宠已运行，请从原窗口右键菜单退出。"); return 2; }
                var app = new Application { ShutdownMode = ShutdownMode.OnMainWindowClose };
                app.DispatcherUnhandledException += (s, e) => { failed = true; Log(e.Exception); e.Handled = true;
                    if (smoke) WriteAtomic(Path.Combine(Root, SmokeReportName()), Json.Serialize(new { passed = false, error = e.Exception.Message }));
                    else MessageBox.Show("桌宠运行失败：" + e.Exception.Message); app.Shutdown(1); };
                BuildWindow(); app.Run(window);
            }
            return failed ? 1 : 0;
        } catch (Exception ex) {
            Log(ex);
            try {
                if (args.Contains("--check") || smoke) WriteAtomic(Path.Combine(Root, args.Contains("--check") ? "check-report.json" : SmokeReportName()), Json.Serialize(new { passed = false, error = ex.Message }));
            } catch { }
            if (!args.Contains("--check") && !smoke) MessageBox.Show("桌宠启动失败：" + ex.Message + "\n详情：exe 同目录 error.log"); return 1;
        }
    }
}
