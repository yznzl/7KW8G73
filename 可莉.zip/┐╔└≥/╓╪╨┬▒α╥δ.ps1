﻿$ErrorActionPreference='Stop'
$framework=Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319'
$source=Join-Path $PSScriptRoot 'source'
$refs=@('System.dll','System.Core.dll','System.Web.Extensions.dll','System.Xaml.dll','WPF\WindowsBase.dll','WPF\PresentationCore.dll','WPF\PresentationFramework.dll') | ForEach-Object {'/reference:'+(Join-Path $framework $_)}
& (Join-Path $framework 'csc.exe') /nologo /target:winexe /platform:anycpu /optimize+ $refs ('/out:'+(Join-Path $PSScriptRoot '可莉桌宠.exe')) ('/win32manifest:'+(Join-Path $source 'pet.manifest')) ('/resource:'+(Join-Path $source 'frames.png')+',sheet-a') (Join-Path $source 'GenshinPet.cs')
if($LASTEXITCODE -ne 0){throw '编译失败'}
