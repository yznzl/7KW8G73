$ErrorActionPreference = 'Stop'
$framework = Join-Path $env:SystemRoot 'Microsoft.NET\Framework64\v4.0.30319'
$source = Join-Path $PSScriptRoot 'source'
$refs = @('System.dll','System.Core.dll','System.Web.Extensions.dll','System.Xaml.dll','WPF\WindowsBase.dll','WPF\PresentationCore.dll','WPF\PresentationFramework.dll') |
    ForEach-Object { '/reference:' + (Join-Path $framework $_) }
$assets = 192,288,384 | ForEach-Object { '/resource:' + (Join-Path $source "atlas-$_.png") + ",atlas-$_" }
& (Join-Path $framework 'csc.exe') /nologo /target:winexe /platform:anycpu /optimize+ $refs $assets `
    ('/out:' + (Join-Path $PSScriptRoot '威尔逊桌宠.exe')) (Join-Path $source 'WilsonPet.cs') (Join-Path $source 'PetSettings.cs')
if ($LASTEXITCODE -ne 0) { throw '威尔逊桌宠编译失败' }

