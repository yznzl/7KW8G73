using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Web.Script.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Threading;

sealed partial class WilsonPet
{
    [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr hwnd, int id, uint modifiers, uint key);
    [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr hwnd, int id);

    public sealed class Settings
    {
        public bool Auto { get; set; }
        public double Interval { get; set; }
        public double Duration { get; set; }
        public string[] Shortcuts { get; set; }

        public Settings()
        {
            Interval = 5;
            Shortcuts = new string[Actions.Length];
        }
    }

    readonly MenuItem[] actionItems = new MenuItem[Actions.Length];
    readonly DispatcherTimer autoTimer = new DispatcherTimer();
    readonly Random random = new Random();
    readonly JavaScriptSerializer json = new JavaScriptSerializer();
    Settings settings = new Settings();
    string settingsPath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "WilsonDesktopPet", "settings.json");
    DateTime automaticUntil;
    HwndSource hwnd;
    MenuItem autoItem, timingItem;
    bool settingsOpen;

    void LoadSettings()
    {
        if (!File.Exists(settingsPath)) return;
        try {
            var loaded = json.Deserialize<Settings>(File.ReadAllText(settingsPath));
            if (loaded == null || loaded.Shortcuts == null || loaded.Shortcuts.Length != Actions.Length ||
                !InRange(loaded.Interval, 1, 86400) || !InRange(loaded.Duration, 0, 3600))
                throw new InvalidDataException("设置格式无效。");
            settings = loaded;
        } catch (Exception error) {
            MessageBox.Show("读取设置失败，已使用默认值。\n" + error.Message, "威尔逊桌宠");
        }
    }

    static bool InRange(double value, double min, double max)
    {
        return value >= min && value <= max;
    }

    void SaveSettings(Settings candidate)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(settingsPath));
        string temporary = settingsPath + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try {
            File.WriteAllText(temporary, json.Serialize(candidate));
            if (File.Exists(settingsPath)) File.Replace(temporary, settingsPath, null);
            else File.Move(temporary, settingsPath);
        } finally {
            if (File.Exists(temporary)) File.Delete(temporary);
        }
        settings = candidate;
    }

    Settings CopySettings()
    {
        return new Settings { Auto = settings.Auto, Interval = settings.Interval,
            Duration = settings.Duration, Shortcuts = (string[])settings.Shortcuts.Clone() };
    }

    void AddSettingsMenu(ContextMenu menu)
    {
        autoItem = new MenuItem { Header = "自动随机动作", IsCheckable = true };
        autoItem.Click += (s, e) => {
            var candidate = CopySettings();
            candidate.Auto = autoItem.IsChecked;
            try {
                SaveSettings(candidate);
                if (!settings.Auto && automaticUntil != DateTime.MinValue) Play(0);
            } catch (Exception error) {
                MessageBox.Show("保存失败：" + error.Message, "威尔逊桌宠");
            }
            ApplyTiming();
        };
        timingItem = new MenuItem();
        timingItem.Click += (s, e) => EditSettings(false);
        var shortcuts = new MenuItem { Header = "快捷键设置…" };
        shortcuts.Click += (s, e) => EditSettings(true);
        menu.Items.Add(autoItem);
        menu.Items.Add(timingItem);
        menu.Items.Add(shortcuts);
        menu.Items.Add(new Separator());
    }

    void StartSettings()
    {
        hwnd = (HwndSource)PresentationSource.FromVisual(this);
        hwnd.AddHook(HotkeyMessage);
        string errors = RegisterShortcuts(settings.Shortcuts);
        if (errors.Length != 0) MessageBox.Show(errors, "部分快捷键不可用");
        autoTimer.Tick += (s, e) => TryAutoPlay();
        ApplyTiming();
    }

    void ApplyTiming()
    {
        autoItem.IsChecked = settings.Auto;
        timingItem.Header = "自动播放设置（每 " + settings.Interval.ToString(CultureInfo.InvariantCulture) + " 秒）…";
        autoTimer.Stop();
        autoTimer.Interval = TimeSpan.FromSeconds(settings.Interval);
        if (settings.Auto) autoTimer.Start();
    }

    void TryAutoPlay()
    {
        if (!settings.Auto || row != 0 || pressed || settingsOpen || sprite.ContextMenu.IsOpen) return;
        Play(random.Next(1, Actions.Length));
        if (settings.Duration > 0) automaticUntil = DateTime.UtcNow.AddSeconds(settings.Duration);
    }

    void UnregisterShortcuts()
    {
        if (hwnd == null || hwnd.IsDisposed) return;
        for (int i = 0; i < Actions.Length; i++) UnregisterHotKey(hwnd.Handle, i + 1);
    }

    IntPtr HotkeyMessage(IntPtr handle, int message, IntPtr wParam, IntPtr lParam, ref bool handled)
    {
        if (message != 0x0312) return IntPtr.Zero;
        long action = wParam.ToInt64() - 1;
        if (action >= 0 && action < Actions.Length) {
            if (!settingsOpen && !pressed) Play((int)action);
            handled = true;
        }
        return IntPtr.Zero;
    }

    static bool ParseShortcut(string text, out uint modifiers, out uint key)
    {
        modifiers = key = 0;
        string[] parts = text.Split('+');
        for (int i = 0; i < parts.Length - 1; i++) {
            switch (parts[i]) {
                case "Alt": modifiers |= 1; break;
                case "Ctrl": modifiers |= 2; break;
                case "Shift": modifiers |= 4; break;
                default: return false;
            }
        }
        Key parsed;
        if ((modifiers & 3) == 0 || !Enum.TryParse(parts[parts.Length - 1], out parsed) ||
            !Enum.IsDefined(typeof(Key), parsed)) return false;
        key = (uint)KeyInterop.VirtualKeyFromKey(parsed);
        return key != 0;
    }

    string RegisterShortcuts(string[] bindings)
    {
        UnregisterShortcuts();
        var seen = new HashSet<uint>();
        var errors = new List<string>();
        for (int i = 0; i < bindings.Length; i++) {
            string binding = bindings[i];
            actionItems[i].InputGestureText = "";
            if (String.IsNullOrEmpty(binding)) continue;
            uint modifiers, key;
            string error = null;
            if (!ParseShortcut(binding, out modifiers, out key)) error = "组合键无效";
            else if (!seen.Add((modifiers << 16) | key)) error = "与其他动作重复";
            else if (!RegisterHotKey(hwnd.Handle, i + 1, modifiers | 0x4000, key)) error = "已被系统或其他程序占用";
            if (error == null) actionItems[i].InputGestureText = binding;
            else errors.Add(Actions[i] + "（" + binding + "）：" + error);
        }
        return String.Join("\n", errors);
    }

    void EditSettings(bool shortcuts)
    {
        settingsOpen = true;
        var candidate = CopySettings();
        var dialog = new Window { Title = shortcuts ? "快捷键设置" : "自动播放设置", Owner = this,
            Width = 450, SizeToContent = SizeToContent.Height, WindowStartupLocation = WindowStartupLocation.CenterScreen,
            ResizeMode = ResizeMode.NoResize, ShowInTaskbar = false, Topmost = true };
        var panel = new StackPanel { Margin = new Thickness(16) };
        dialog.Content = panel;
        TextBox interval = null, duration = null;
        if (shortcuts) {
            UnregisterShortcuts();
            panel.Children.Add(new TextBlock { Text = "点击输入框后按组合键，需包含 Ctrl 或 Alt。" });
            for (int i = 0; i < Actions.Length; i++) {
                int index = i;
                var line = new DockPanel { Margin = new Thickness(0, 5, 0, 0) };
                var label = new TextBlock { Text = Actions[i], Width = 70, VerticalAlignment = VerticalAlignment.Center };
                DockPanel.SetDock(label, Dock.Left);
                line.Children.Add(label);
                var clear = new Button { Content = "清除", Width = 54, Margin = new Thickness(6, 0, 0, 0) };
                DockPanel.SetDock(clear, Dock.Right);
                line.Children.Add(clear);
                var box = new TextBox { Text = candidate.Shortcuts[i] ?? "", IsReadOnly = true, Padding = new Thickness(4) };
                line.Children.Add(box);
                panel.Children.Add(line);
                clear.Click += (s, e) => { candidate.Shortcuts[index] = null; box.Clear(); };
                box.PreviewKeyDown += (s, e) => {
                    e.Handled = true;
                    Key key = e.Key == Key.System ? e.SystemKey : e.Key;
                    var mods = Keyboard.Modifiers;
                    if ((mods & ModifierKeys.Windows) != 0 || key == Key.LeftCtrl || key == Key.RightCtrl ||
                        key == Key.LeftAlt || key == Key.RightAlt || key == Key.LeftShift || key == Key.RightShift) return;
                    string binding = ((mods & ModifierKeys.Control) != 0 ? "Ctrl+" : "") +
                        ((mods & ModifierKeys.Alt) != 0 ? "Alt+" : "") +
                        ((mods & ModifierKeys.Shift) != 0 ? "Shift+" : "") + key;
                    uint parsedMods, parsedKey;
                    if (!ParseShortcut(binding, out parsedMods, out parsedKey)) return;
                    candidate.Shortcuts[index] = box.Text = binding;
                };
            }
        } else {
            interval = AddNumberField(panel, "随机动作间隔（秒，1–86400）", settings.Interval);
            duration = AddNumberField(panel, "每次自动播放时长（秒，0 表示完整播一遍）", settings.Duration);
        }
        var errorText = new TextBlock { Foreground = System.Windows.Media.Brushes.DarkRed, TextWrapping = TextWrapping.Wrap };
        panel.Children.Add(errorText);
        var footer = new StackPanel { Orientation = Orientation.Horizontal, HorizontalAlignment = HorizontalAlignment.Right,
            Margin = new Thickness(0, 12, 0, 0) };
        var save = new Button { Content = "保存", Width = 70, IsDefault = true };
        var cancel = new Button { Content = "取消", Width = 70, IsCancel = true, Margin = new Thickness(8, 0, 0, 0) };
        footer.Children.Add(save);
        footer.Children.Add(cancel);
        panel.Children.Add(footer);
        bool saved = false;
        save.Click += (s, e) => {
            try {
                if (shortcuts) {
                    string errors = RegisterShortcuts(candidate.Shortcuts);
                    if (errors.Length != 0) throw new InvalidOperationException(errors);
                } else {
                    candidate.Interval = ReadNumber(interval.Text, 1, 86400, "随机动作间隔");
                    candidate.Duration = ReadNumber(duration.Text, 0, 3600, "自动播放时长");
                }
                SaveSettings(candidate);
                saved = true;
                if (!shortcuts) ApplyTiming();
                dialog.Close();
            } catch (Exception error) {
                if (shortcuts) UnregisterShortcuts();
                errorText.Text = error.Message;
            }
        };
        try {
            dialog.ShowDialog();
        } finally {
            settingsOpen = false;
            if (shortcuts && !saved) {
                string errors = RegisterShortcuts(settings.Shortcuts);
                if (errors.Length != 0) MessageBox.Show(errors, "部分原快捷键无法恢复");
            }
        }
    }

    static TextBox AddNumberField(StackPanel panel, string label, double value)
    {
        panel.Children.Add(new TextBlock { Text = label, Margin = new Thickness(0, 7, 0, 3) });
        var field = new TextBox { Text = value.ToString(CultureInfo.InvariantCulture), Padding = new Thickness(4) };
        panel.Children.Add(field);
        return field;
    }

    static double ReadNumber(string text, double min, double max, string label)
    {
        double result;
        if (!Double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out result) || !InRange(result, min, max))
            throw new ArgumentException(label + "请输入 " + min + "–" + max + " 秒。");
        return result;
    }

    void SmokeSettings()
    {
        settingsPath = Path.Combine(Path.GetTempPath(), "wilson-smoke-" + Guid.NewGuid().ToString("N") + ".json");
        try {
            var candidate = CopySettings();
            candidate.Auto = true;
            candidate.Interval = ReadNumber("2.5", 1, 86400, "间隔");
            candidate.Duration = 1;
            candidate.Shortcuts[3] = "Ctrl+Alt+Shift+F10";
            SaveSettings(candidate);
            settings = new Settings();
            LoadSettings();
            ApplyTiming();
            if (!autoTimer.IsEnabled || autoTimer.Interval.TotalSeconds != 2.5 || settings.Duration != 1 ||
                RegisterShortcuts(settings.Shortcuts).Length != 0)
                throw new InvalidOperationException("自动播放或快捷键设置检查失败。");
            bool handled = false;
            HotkeyMessage(hwnd.Handle, 0x0312, new IntPtr(4), IntPtr.Zero, ref handled);
            if (!handled || row != 3) throw new InvalidOperationException("快捷键没有触发动作。");
            Play(0);
            TryAutoPlay();
            if (row == 0 || automaticUntil <= DateTime.UtcNow) throw new InvalidOperationException("自动动作没有启动。");
            candidate.Shortcuts[4] = candidate.Shortcuts[3];
            if (!RegisterShortcuts(candidate.Shortcuts).Contains("重复")) throw new InvalidOperationException("重复快捷键未被拦截。");
        } finally {
            if (File.Exists(settingsPath)) File.Delete(settingsPath);
        }
    }
}

