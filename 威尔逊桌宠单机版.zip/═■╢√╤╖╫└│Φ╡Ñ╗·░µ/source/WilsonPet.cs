using System;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

sealed partial class WilsonPet : Window
{
    static readonly int[] Counts = { 6, 8, 8, 4, 5, 8, 6, 6, 6 };
    static readonly int[] Delays = { 200, 90, 90, 145, 115, 140, 175, 155, 170 };
    static readonly string[] Actions = { "待机", "向右跑", "向左跑", "挥手", "跳跃", "受挫", "等待", "忙碌", "查看" };
    static readonly int[] Sizes = { 192, 288, 384 };
    readonly Image sprite = new Image { Stretch = Stretch.Fill };
    readonly DispatcherTimer timer = new DispatcherTimer();
    readonly MenuItem[] sizeItems = new MenuItem[3];
    BitmapSource[][] frames;
    int row, frame, size = 1;
    bool pressed, dragging, hovered;
    Point down, last;
    double initialLeft, initialTop;

    WilsonPet(bool smoke)
    {
        if (!smoke) LoadSettings();
        Title = "威尔逊桌宠";
        WindowStyle = WindowStyle.None;
        AllowsTransparency = true;
        Background = Brushes.Transparent;
        ResizeMode = ResizeMode.NoResize;
        ShowInTaskbar = false;
        ShowActivated = false;
        Topmost = true;
        UseLayoutRounding = true;
        SnapsToDevicePixels = true;
        Content = sprite;
        RenderOptions.SetBitmapScalingMode(sprite, BitmapScalingMode.HighQuality);
        var menu = new ContextMenu();
        for (int i = 0; i < Actions.Length; i++) {
            int action = i;
            var item = new MenuItem { Header = Actions[i] };
            item.Click += (s, e) => Play(action);
            menu.Items.Add(item);
            actionItems[i] = item;
        }
        menu.Items.Add(new Separator());
        AddSettingsMenu(menu);
        var scale = new MenuItem { Header = "显示大小" };
        menu.Items.Add(scale);
        for (int i = 0; i < Sizes.Length; i++) {
            int choice = i;
            var item = new MenuItem { Header = (100 + 50 * i) + "%", IsCheckable = true };
            sizeItems[i] = item;
            item.Click += (s, e) => SetSize(choice, false);
            scale.Items.Add(item);
        }
        var exit = new MenuItem { Header = "退出" };
        exit.Click += (s, e) => Close();
        menu.Items.Add(exit);
        sprite.ContextMenu = menu;
        sprite.MouseEnter += (s, e) => {
            if (!hovered && !pressed && !menu.IsOpen && row == 0) Play(4);
            hovered = true;
        };
        sprite.MouseLeave += (s, e) => { if (!pressed) hovered = false; };
        sprite.MouseLeftButtonDown += (s, e) => {
            down = last = sprite.PointToScreen(e.GetPosition(sprite));
            initialLeft = Left;
            initialTop = Top;
            pressed = sprite.CaptureMouse();
            e.Handled = true;
        };
        sprite.MouseMove += (s, e) => {
            if (!pressed) return;
            Point point = sprite.PointToScreen(e.GetPosition(sprite));
            Vector offset = point - down;
            if (!dragging && offset.Length < 5) return;
            dragging = true;
            var dpi = PresentationSource.FromVisual(this).CompositionTarget.TransformToDevice;
            Left = initialLeft + offset.X / dpi.M11;
            Top = initialTop + offset.Y / dpi.M22;
            if (point.X != last.X) {
                int direction = point.X > last.X ? 1 : 2;
                if (row != direction) Play(direction);
            } else if (row != 1 && row != 2) Play(1);
            last = point;
        };
        sprite.MouseLeftButtonUp += (s, e) => {
            if (!pressed) return;
            bool moved = dragging;
            pressed = dragging = false;
            sprite.ReleaseMouseCapture();
            hovered = sprite.IsMouseOver;
            Play(moved ? 0 : 3);
            e.Handled = true;
        };
        sprite.LostMouseCapture += (s, e) => {
            if (pressed) {
                pressed = dragging = false;
                Play(0);
            }
        };
        timer.Tick += (s, e) => {
            if (automaticUntil != DateTime.MinValue && DateTime.UtcNow >= automaticUntil) {
                Play(0);
                return;
            }
            if (frame + 1 < Counts[row]) {
                sprite.Source = frames[row][++frame];
            } else {
                if (automaticUntil > DateTime.UtcNow) {
                    frame = 0;
                    sprite.Source = frames[row][frame];
                } else {
                    Play(dragging || row == 0 ? row : 0);
                }
            }
        };
        SourceInitialized += (s, e) => { SetSize(size, true); Play(0); timer.Start(); StartSettings(); };
        Closed += (s, e) => { timer.Stop(); autoTimer.Stop(); UnregisterShortcuts(); };
    }

    void SetSize(int choice, bool first)
    {
        int width = Sizes[choice], height = width * 208 / 192;
        BitmapSource atlas;
        using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("atlas-" + width))
            atlas = BitmapFrame.Create(stream, BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.OnLoad);
        if (atlas.PixelWidth != width * 8 || atlas.PixelHeight != height * Counts.Length)
            throw new InvalidDataException("动画图集尺寸错误。");
        frames = new BitmapSource[Counts.Length][];
        for (int r = 0; r < Counts.Length; r++) {
            frames[r] = new BitmapSource[Counts[r]];
            for (int c = 0; c < Counts[r]; c++) {
                var crop = new CroppedBitmap(atlas, new Int32Rect(c * width, r * height, width, height));
                crop.Freeze();
                frames[r][c] = crop;
            }
        }
        var dpi = PresentationSource.FromVisual(this).CompositionTarget.TransformToDevice;
        var work = SystemParameters.WorkArea;
        double center = first ? work.Right - width / dpi.M11 / 2 - 24 : Left + Width / 2;
        double bottom = first ? work.Bottom - 20 : Top + Height;
        Width = width / dpi.M11;
        Height = height / dpi.M22;
        Left = Math.Max(work.Left, Math.Min(work.Right - Width, center - Width / 2));
        Top = Math.Max(work.Top, Math.Min(work.Bottom - Height, bottom - Height));
        Left = Math.Round(Left * dpi.M11) / dpi.M11;
        Top = Math.Round(Top * dpi.M22) / dpi.M22;
        size = choice;
        for (int i = 0; i < sizeItems.Length; i++) sizeItems[i].IsChecked = i == size;
        sprite.Source = frames[row][frame];
    }

    void Play(int action)
    {
        automaticUntil = DateTime.MinValue;
        row = action;
        frame = 0;
        sprite.Source = frames[row][frame];
        timer.Interval = TimeSpan.FromMilliseconds(Delays[row]);
    }

    void Smoke()
    {
        for (int i = 0; i < Sizes.Length; i++) {
            SetSize(i, false);
            UpdateLayout();
            var dpi = PresentationSource.FromVisual(this).CompositionTarget.TransformToDevice;
            if (Math.Abs(ActualWidth * dpi.M11 - Sizes[i]) > 1 ||
                Math.Abs(ActualHeight * dpi.M22 - Sizes[i] * 208 / 192) > 1)
                throw new InvalidOperationException("缩放后的窗口尺寸错误。");
            for (int action = 0; action < Counts.Length; action++) {
                Play(action);
                if (sprite.Source != frames[action][0] || frames[action].Length != Counts[action])
                    throw new InvalidOperationException(Actions[action]);
            }
        }
    }

    [STAThread]
    static int Main(string[] args)
    {
        bool smoke = args.Length == 1 && args[0] == "--smoke";
        try {
            var app = new Application();
            var pet = new WilsonPet(smoke);
            if (smoke) {
                pet.Show();
                pet.Smoke();
                pet.SmokeSettings();
                pet.Close();
                return 0;
            }
            return app.Run(pet);
        } catch (Exception error) {
            if (!smoke) MessageBox.Show(error.Message, "威尔逊桌宠");
            return 1;
        }
    }
}

