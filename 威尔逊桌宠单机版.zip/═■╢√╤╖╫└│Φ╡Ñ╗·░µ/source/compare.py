from PIL import Image, ImageDraw
from pathlib import Path
root = Path.cwd()
pet = Image.open(Path.home()/'.codex/pets/wilson-original-v2/spritesheet.webp')
samples = [(pet.crop((0,0,192,208)), 'Wilson / Lanczos', Image.Resampling.LANCZOS),
           (pet.crop((0,0,192,208)), 'Wilson / Nearest', Image.Resampling.NEAREST),
           (Image.open(next(root.glob('路飞桌宠/source/assets/luffy-a.png'))).crop((0,0,384,416)), 'Luffy / 150%', Image.Resampling.LANCZOS),
           (Image.open(next(root.glob('索隆桌宠/source/assets/zoro.png'))).crop((0,0,384,416)), 'Zoro / 150%', Image.Resampling.LANCZOS)]
out = Image.new('RGB',(1152,342),'#bac5cc')
draw=ImageDraw.Draw(out)
for i,(frame,label,sampling) in enumerate(samples):
    frame=frame.convert('RGBA').resize((288,312),sampling)
    out.paste(frame,(i*288,30),frame)
    draw.text((i*288+15,10),label,fill='black')
out.save(root/'威尔逊桌宠单机版'/'150%对照.png')
