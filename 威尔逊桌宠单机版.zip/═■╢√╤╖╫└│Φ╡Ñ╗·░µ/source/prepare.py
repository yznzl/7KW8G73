from pathlib import Path
from PIL import Image, ImageDraw

root = Path(__file__).resolve().parent
sheet = Image.open(root / "spritesheet.webp").convert("RGBA")
counts = (6, 8, 8, 4, 5, 8, 6, 6, 6)
assert sheet.size == (1536, 2288)
idle = sheet.crop((0, 0, 192, 208)).getbbox()
idle_height = idle[3] - idle[1]
jump_lifts = (0, 7, 15, 7, 0)
def trim_pose(image):
    alpha = image.getchannel("A").point(lambda value: min(255, max(0, (value - 140) * 255 // 100)))
    image.putalpha(alpha)
    return image.crop(alpha.getbbox())

crouch = trim_pose(Image.open(root / "jump-crouch.png").convert("RGBA"))
strip = Image.open(root / "jump-airborne.png").convert("RGBA")
airborne = [
    trim_pose(strip.crop((strip.width * index // 3, 0, strip.width * (index + 1) // 3, strip.height)))
    for index in range(3)
]
jump_poses = [crouch, *airborne, crouch]
for width in (192, 288, 384):
    height = width * 208 // 192
    atlas = Image.new("RGBA", (width * 8, height * len(counts)))
    for row, count in enumerate(counts):
        for column in range(count):
            x, y = column * 192, row * 208
            frame = sheet.crop((x, y, x + 192, y + 208))
            assert frame.getbbox(), (row, column)
            if row == 4:
                pose = jump_poses[column]
                pose_width = round(pose.width * idle_height / pose.height)
                assert pose_width <= 192
                # Scale from the original pose once, then place on the shared ground line.
                scale = width / 192
                pose = pose.resize((round(pose_width * scale), round(idle_height * scale)),
                                   Image.Resampling.LANCZOS)
                frame = Image.new("RGBA", (width, height))
                y = round((idle[3] - jump_lifts[column]) * scale) - pose.height
                assert y >= 0
                frame.paste(pose, ((width - pose.width) // 2, y))
            else:
                frame = frame.resize((width, height), Image.Resampling.LANCZOS)
            atlas.paste(frame, (column * width, row * height))
    atlas.save(root / f"atlas-{width}.png", optimize=True)

    if width == 288:
        comparison = Image.new("RGB", (width * 6, height + 30), "#bac5cc")
        draw = ImageDraw.Draw(comparison)
        cells = [(0, 0, "Idle")] + [(4, c, f"Jump {c + 1}") for c in range(5)]
        for i, (row, column, label) in enumerate(cells):
            x, y = column * width, row * height
            pose = atlas.crop((x, y, x + width, y + height))
            comparison.paste(pose, (i * width, 30), pose)
            draw.text((i * width + 14, 10), label, fill="black")
        comparison.save(root.parent / "150%跳跃对照.png")


