"""Rebuild the 2x atlas from the archived Codex sprite sheet (Pillow, numpy, vtracer, resvg-py)."""
from io import BytesIO
from pathlib import Path

import numpy as np
from PIL import Image
from resvg_py import svg_to_bytes
from vtracer import convert_pixels_to_svg

ROOT = Path(__file__).resolve().parent
COUNTS = (6, 8, 8, 4, 5, 8, 6, 6, 6)
PALETTES = (
    "5e3528 fdfdfe 70c7ed f3d09c d0b699 745e5a 896f67 aca8a8 eee2cc 325098 a3ddef",
    "fefefe d1b59b 5f3226 2e50a1",
    "fefefe d1b59b 5f3226 2e50a1",
    "fafafc dfb896 613528 f9c18e dca170 3152a1 8d5129 f66c67",
    "fdfcff d8b3aa d0b699 5e3528 2450aa eee2cc",
    "f8f9fa 603529 d5b4a0 3151a0 f96c6a d7e5e2 ef9fa4 f7e9a6",
    "f5d29a fcfcfe 643628 948f90 786a67 eee2cc d1b59a 314f9e 867c84",
    "f5d299 fdfcfb 5e3528 d1b698 968c8b 786866 fbdc31 33519a",
    "fefefe f5d097 d0b69a 7a6866 62362a acacaf e6dcc9 335198 b1b7c1",
)
WIDTH, HEIGHT = 192, 208
HD_SIZE = (WIDTH * 2, HEIGHT * 2)


def cell(sheet, row, frame):
    return sheet.crop((frame * WIDTH, row * HEIGHT, (frame + 1) * WIDTH, (row + 1) * HEIGHT))


def redraw(sprite, colors):
    rgba = np.array(sprite.resize(HD_SIZE, Image.Resampling.BICUBIC))
    distances = ((rgba[:, :, :3, None] - colors.T) ** 2).sum(axis=2)
    rgba[:, :, :3] = colors[distances.argmin(axis=2)]
    opaque = rgba[:, :, 3] >= 128
    rgba[~opaque] = 0
    rgba[opaque, 3] = 255
    return convert_pixels_to_svg(
        list(map(tuple, rgba.reshape(-1, 4).tolist())), HD_SIZE,
        hierarchical="stacked", mode="spline", filter_speckle=4,
        color_precision=8, layer_difference=0, corner_threshold=75,
        length_threshold=6, splice_threshold=50, path_precision=3,
    )


def main():
    sheet = Image.open(ROOT / "original.webp").convert("RGBA")
    assert sheet.size == (WIDTH * 8, HEIGHT * len(COUNTS))
    atlas = Image.new("RGBA", (HD_SIZE[0] * 8, HD_SIZE[1] * len(COUNTS)))
    for row, count in enumerate(COUNTS):
        colors = np.array([list(bytes.fromhex(h)) for h in PALETTES[row].split()], dtype="float32")
        for frame in range(count):
            sprite = cell(sheet, row, frame)
            if row in (1, 2) and frame == 7:
                # shortcut: the original last pose is clipped, reuse the closest intact pose until an uncropped source is available.
                sprite = Image.new("RGBA", (WIDTH, HEIGHT))
                sprite.paste(cell(sheet, row, 1), (11 if row == 1 else -11, 0))
            svg = redraw(sprite, colors)
            raster = Image.open(BytesIO(svg_to_bytes(svg_string=svg))).convert("RGBA")
            bounds = raster.getbbox()
            assert raster.size == HD_SIZE and bounds and raster.getpixel((0, 0))[3] == 0
            atlas.paste(raster, (frame * HD_SIZE[0], row * HD_SIZE[1]))
    atlas.save(ROOT / "frames.png", optimize=True)


if __name__ == "__main__":
    main()
