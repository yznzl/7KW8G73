"""Reconstruct diagonal contours at 2× while keeping the original frame geometry."""
from pathlib import Path
import sys

import numpy as np
from PIL import Image

WIDTH, HEIGHT = 192, 208
ROW_COUNTS = (6, 8, 8, 4, 5, 8, 6, 6, 6)


def clean_matte(frame, zoro):
    pixels = np.asarray(frame).astype(np.float32)
    red, green, blue, alpha = pixels.transpose(2, 0, 1)
    if zoro:
        # Use a narrow hue test to protect the purple blade.
        magenta = (red > 0.87 * blue) & (blue > 0.85 * red) & (green < 0.29 * red)
    else:
        magenta = (red > 0.76 * blue) & (blue > 0.74 * red) & (green < 0.48 * red)

    alpha[(alpha < 14) | (magenta & (red >= 55))] = 0
    # Reduce purple spill in the very dark edge pixels.
    dark_matte = magenta & (red < 55)
    red[dark_matte] = np.minimum(red[dark_matte], green[dark_matte] + 12)
    blue[dark_matte] = np.minimum(blue[dark_matte], green[dark_matte] + 12)
    return pixels


def distance(a, b):
    delta = a - b
    return (np.abs(delta[..., 0]) * 0.30 + np.abs(delta[..., 1]) * 0.55
            + np.abs(delta[..., 2]) * 0.15 + np.abs(delta[..., 3]) * 0.55)


def redraw(frame, zoro):
    pixels = clean_matte(frame, zoro)
    pixels[..., :3] *= pixels[..., 3:] / 255
    p = np.pad(pixels, ((1, 1), (1, 1), (0, 0)), mode="constant")
    n, s = p[:-2, 1:-1], p[2:, 1:-1]
    w, e = p[1:-1, :-2], p[1:-1, 2:]
    nw, ne, sw, se = p[:-2, :-2], p[:-2, 2:], p[2:, :-2], p[2:, 2:]
    output = np.repeat(np.repeat(pixels, 2, axis=0), 2, axis=1)

    for y, x, side1, side2, across1, across2, diagonal in (
        (0, 0, n, w, s, e, nw), (0, 1, n, e, s, w, ne),
        (1, 0, s, w, n, e, sw), (1, 1, s, e, n, w, se),
    ):
        # Draw a smooth corner when both neighboring pixels follow the same edge.
        match = distance(side1, side2)
        separation = np.minimum(distance(pixels, side1), distance(pixels, side2))
        edge = (match < 19) & (separation > 20) & (match < separation * 0.49)
        edge &= (distance(side1, across1) > match + 13) | (distance(side2, across2) > match + 13)
        straight = distance(diagonal, pixels) < np.minimum(distance(diagonal, side1), distance(diagonal, side2))
        weight = np.where(edge, np.where(straight, 0.24, 0.68), 0)[..., None]
        output[y::2, x::2] = pixels * (1 - weight) + (side1 + side2) * (weight / 2)

    alpha = output[..., 3:]
    np.divide(output[..., :3] * 255, alpha, out=output[..., :3], where=alpha > 0)
    output[output[..., 3] < 1] = 0
    return Image.fromarray(np.clip(output.round(), 0, 255).astype(np.uint8))


def average(field):
    p=np.pad(field,2,mode="edge")
    h,w=field.shape
    return sum(p[y:y+h,x:x+w] for y in range(5) for x in range(5))/25

def sample(image,y,x):
    h,w=image.shape[:2]
    x=np.clip(x,0,w-1)
    y=np.clip(y,0,h-1)
    x0=x.astype(np.intp)
    y0=y.astype(np.intp)
    x1=np.minimum(x0+1,w-1)
    y1=np.minimum(y0+1,h-1)
    u=(x-x0)[...,None]
    v=(y-y0)[...,None]
    return (image[y0,x0]*(1-u)+image[y0,x1]*u)*(1-v)+(image[y1,x0]*(1-u)+image[y1,x1]*u)*v

def refine(image):
    # Smooth along a local edge, so narrow outlines are preserved across the edge.
    p=np.asarray(image,dtype=np.float32)
    p[...,:3] *= p[...,3:]/255
    light=p[...,:3]@np.array([.24,.65,.11],dtype=np.float32)
    ly,lx=np.gradient(light)
    ay,ax=np.gradient(p[...,3])
    xx=average(lx*lx + ax*ax*.8)
    yy=average(ly*ly + ay*ay*.8)
    xy=average(lx*ly + ax*ay*.8)
    coherence=np.sqrt((xx-yy)**2+4*xy*xy)/(xx+yy+1)
    angle=.5*np.arctan2(2*xy,xx-yy)
    dy=np.cos(angle)
    dx=-np.sin(angle)
    y,x=np.indices(light.shape,dtype=np.float32)
    edge=np.minimum(np.maximum(coherence-.38,0)*2.3,.92)*np.minimum((xx+yy)/48,1)
    smooth=(sample(p,y+dy,x+dx)+sample(p,y-dy,x-dx))*.33
    smooth+=(sample(p,y+2*dy,x+2*dx)+sample(p,y-2*dy,x-2*dx))*.17
    out=p*(1-edge[...,None])+smooth*edge[...,None]
    np.divide(out[...,:3]*255,out[...,3:],out=out[...,:3],where=out[...,3:]>0)
    return Image.fromarray(np.clip(out.round(),0,255).astype(np.uint8))

def process(source, target, zoro):
    sheet = Image.open(source).convert("RGBA")
    assert sheet.size == (8 * WIDTH, len(ROW_COUNTS) * HEIGHT), source
    atlas = Image.new("RGBA", (sheet.width * 2, sheet.height * 2))
    for row, count in enumerate(ROW_COUNTS):
        for index in range(count):
            left, top = index * WIDTH, row * HEIGHT
            frame = sheet.crop((left, top, left + WIDTH, top + HEIGHT))
            rendered = refine(redraw(frame, zoro))
            alpha = rendered.getchannel("A")
            assert alpha.getextrema() == (0, 255), (source, row, index)
            assert alpha.point(lambda x: 255 if x >= 32 else 0).getbbox(), (source, row, index)
            atlas.paste(rendered, (left * 2, top * 2))
    atlas.save(target)


if __name__ == "__main__":
    source, target, character = sys.argv[1:]
    process(Path(source), Path(target), character == "zoro")
