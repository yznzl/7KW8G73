﻿using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using System.Web.Script.Serialization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using System.Threading;
using System.Diagnostics;
using System.Globalization;
using Microsoft.Win32;

class GenshinPet {
    [DllImport("user32.dll")] static extern bool RegisterHotKey(IntPtr h, int id, uint mod, uint key);
    [DllImport("user32.dll")] static extern bool UnregisterHotKey(IntPtr h, int id);
    [DllImport("user32.dll",SetLastError=true)] static extern UIntPtr SetTimer(IntPtr h,UIntPtr id,uint interval,IntPtr callback);
    [DllImport("user32.dll")] static extern bool KillTimer(IntPtr h,UIntPtr id);
    static readonly string Root = AppDomain.CurrentDomain.BaseDirectory;
    const string PetId = "GenshinStandalone-yoimiya--chenxin-dlut";
    const string PetName = "宵宫";
    const int StartGap = 20;
    static readonly string[] Appearances = {"宵宫"};

    const int FrameWidth = 192;
    const int FrameHeight = 208;
    static readonly int[] RowCounts = {6, 8, 8, 4, 5, 8, 6, 6, 6};
    static readonly string[] ActionNames = {"待机", "向右跑", "向左跑", "挥手", "跳跃", "失落", "等待回应", "思考 / 工作", "观察"};
    static readonly int[][] RowTimings = {
        new[] {900, 100, 140, 900, 100, 140},
        new[] {100, 100, 100, 100, 100, 100, 100, 100},
        new[] {100, 100, 100, 100, 100, 100, 100, 100},
        new[] {160, 160, 200, 160},
        new[] {140, 100, 180, 100, 160},
        new[] {180, 180, 180, 180, 180, 180, 180, 180},
        new[] {180, 180, 180, 180, 180, 180},
        new[] {220, 220, 220, 220, 220, 220},
        new[] {240, 240, 240, 240, 240, 240}
    };
    static int[] Counts;
    static string[] Names;
    static int[][] FrameTimings;
    static int appearance;
    static int IdleAction { get { return appearance * RowCounts.Length; } }
    static Dictionary<string,object> cfg;
    static readonly JavaScriptSerializer json = new JavaScriptSerializer();
    static BitmapSource[][] frames;
    static int dragDirection;
    static double dragLastX;
    static readonly UIntPtr DragTimerId=new UIntPtr(0x53594C50);
    static UIntPtr activeDragTimer=UIntPtr.Zero;
    static bool dragOverride;
    static readonly Stopwatch dragClock=Stopwatch.StartNew();
    static Window window;
    static Image image;
    static DispatcherTimer timer, randomTimer;
    static ContextMenu menu;
    static MenuItem[] actionItems;
    static MenuItem intervalItem;
    static HwndSource source;
    static int row, frame;
    static bool dragging, settingsOpen, smokeMode, runtimeFailed;
    static bool mouseDown, hovering;
    static Point downPoint;
    static Point lastPointerScreen;
    static bool pointerPositionKnown;
    static DateTime lastHover=DateTime.MinValue,lastClick=DateTime.MinValue,quietUntil=DateTime.MinValue;
    static readonly Dictionary<BitmapSource,byte[]> alphaCache=new Dictionary<BitmapSource,byte[]>();
    static readonly Random random=new Random();
    static double actionSeconds;
    static readonly Stopwatch animation=Stopwatch.StartNew();
    static string logPath=Path.Combine(Root,PetName+"桌宠错误日志.txt");
    static void Log(string context, Exception ex) {
        string message=DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss")+" "+context+"\r\n"+ex+"\r\n";
        try {File.AppendAllText(logPath,message);} catch { try {File.AppendAllText(Path.Combine(Path.GetTempPath(),PetId + "-error.log"),message);} catch { } }
    }
    static string ConfigPath { get { return Path.Combine(Root,PetName+"设置.json"); } }
    static Dictionary<string,object> Map(string key) { return (Dictionary<string,object>)cfg[key]; }
    static object Get(string map, int key) {
        object value;
        return Map(map).TryGetValue(key.ToString(), out value) ? value : null;
    }
    static bool ValidAction(int index) { return index >= 0 && index < Counts.Length; }

    static BitmapSource[] ReadRow(BitmapSource atlas, int row, int count) {
        var result = new BitmapSource[count];
        for (int frame = 0; frame < count; frame++) {
            var area = new Int32Rect(frame * FrameWidth, row * FrameHeight, FrameWidth, FrameHeight);
            var bitmap = new CroppedBitmap(atlas, area);
            if (RowTimings[row].Length != count) throw new InvalidDataException("动作时长与帧数不符。");
            var rgba = new FormatConvertedBitmap(bitmap, PixelFormats.Bgra32, null, 0);
            byte[] pixels = new byte[FrameWidth * FrameHeight * 4];
            rgba.CopyPixels(pixels, FrameWidth * 4, 0);
            bool visible = false, transparent = false;
            for (int i = 3; i < pixels.Length; i += 4) { visible |= pixels[i] > 32; transparent |= pixels[i] == 0; }
            if (!visible || !transparent) throw new InvalidDataException("动画帧为空或缺少透明背景。");
            bitmap.Freeze();
            result[frame] = bitmap;
        }
        return result;
    }

    static void Load() {
        cfg = new Dictionary<string,object> {
            {"hotkeys", new Dictionary<string,object>()},
            {"auto_random", true}, {"random_interval", 12.0}, {"scale", 1.5}, {"appearance", 0}
        };
        if (!smokeMode && File.Exists(ConfigPath)) {
            foreach (var pair in json.Deserialize<Dictionary<string,object>>(File.ReadAllText(ConfigPath)))
                cfg[pair.Key] = pair.Value;
        }
        Map("hotkeys");
        Convert.ToBoolean(cfg["auto_random"]);
        ValidateInterval(Convert.ToDouble(cfg["random_interval"]));
        appearance = 0;

        var assembly = typeof(GenshinPet).Assembly;
        var sheets = assembly.GetManifestResourceNames().Where(n => n.StartsWith("sheet-", StringComparison.Ordinal))
            .OrderBy(n => n, StringComparer.Ordinal).ToArray();
        if (sheets.Length != Appearances.Length)
            throw new InvalidDataException("桌宠动作资源数量不正确。");
        Counts = Enumerable.Range(0, sheets.Length).SelectMany(i => RowCounts).ToArray();
        FrameTimings = Enumerable.Range(0, sheets.Length).SelectMany(i => RowTimings).ToArray();
        Names = ActionNames;
        frames = new BitmapSource[Counts.Length][];
        for (int sheet = 0; sheet < sheets.Length; sheet++) {
            BitmapSource atlas;
            using (var stream = assembly.GetManifestResourceStream(sheets[sheet])) {
                atlas = BitmapFrame.Create(stream, BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.OnLoad);
                atlas.Freeze();
            }
            if (atlas.PixelWidth != 8 * FrameWidth || atlas.PixelHeight != RowCounts.Length * FrameHeight)
                throw new InvalidDataException("桌宠动作图集尺寸不正确：" + sheets[sheet]);
            for (int action = 0; action < RowCounts.Length; action++)
                frames[sheet * RowCounts.Length + action] = ReadRow(atlas, action, RowCounts[action]);
        }
    }

    static void ShowFrame(int action, int index) { image.Source = frames[action][index]; }

    static void Save() {
        string temp=ConfigPath+"."+Guid.NewGuid().ToString("N")+".tmp";
        try {File.WriteAllText(temp,json.Serialize(cfg),new System.Text.UTF8Encoding(false));if (File.Exists(ConfigPath)) File.Replace(temp,ConfigPath,null); else File.Move(temp,ConfigPath);}
        finally {if(File.Exists(temp))File.Delete(temp);}
    }
    static void SetAppearance(int choice) {
        int old = appearance;
        cfg["appearance"] = choice;
        try {
            Save();
        } catch (Exception error) {
            cfg["appearance"] = old;
            Log("保存形象失败", error);
            MessageBox.Show("无法保存形象：" + error.Message);
            return;
        }
        appearance = choice;
        Play(IdleAction);
    }
    static void Play(int index) {
        if(!ValidAction(index))throw new ArgumentOutOfRangeException("index");
        if(dragging)dragOverride=index!=IdleAction;
        row=index;frame=0;ShowFrame(row,frame);
        actionSeconds = index == IdleAction ? 0 : FrameTimings[index].Sum() / 1000.0;
        animation.Restart();
    }
    static int ChooseRandomAction() { return IdleAction + random.Next(3, 9); }
    static void ValidateInterval(double seconds) {
        if(Double.IsNaN(seconds)||Double.IsInfinity(seconds))throw new ArgumentException("请输入有效数字。");
        if(seconds<1)throw new ArgumentException("间隔至少为 1 秒。");
        if(seconds>2147483)throw new ArgumentException("间隔不能超过 2147483 秒。");
    }
    static double ParseInterval(string text) {
        if(String.IsNullOrWhiteSpace(text))throw new ArgumentException("请输入间隔秒数。");
        double value;if(!Double.TryParse(text.Trim(),NumberStyles.Float,CultureInfo.InvariantCulture,out value))throw new ArgumentException("请输入有效数字，单位为秒。");
        ValidateInterval(value);return value;
    }
    static string IntervalLabel() {return "随机动作间隔（"+Convert.ToDouble(cfg["random_interval"]).ToString("G",CultureInfo.InvariantCulture)+" 秒）…";}
    static void ChangeInterval(double seconds) {
        ValidateInterval(seconds);object old=cfg["random_interval"];TimeSpan before=randomTimer.Interval;
        try {cfg["random_interval"]=seconds;randomTimer.Interval=TimeSpan.FromSeconds(seconds);Save();if(intervalItem!=null)intervalItem.Header=IntervalLabel();}
        catch {cfg["random_interval"]=old;randomTimer.Interval=before;throw;}
    }
    static void EditInterval() {
        settingsOpen=true;
        var dialog=new Window {Title="随机动作间隔",Owner=window,Width=360,Height=230,WindowStartupLocation=WindowStartupLocation.CenterScreen,Topmost=true};
        var panel=new StackPanel {Margin=new Thickness(16)};
        panel.Children.Add(new TextBlock {Text="间隔单位为秒，最少 1 秒。动作未结束时会跳过当次，不会中断。",TextWrapping=TextWrapping.Wrap});
        var box=new TextBox {Text=Convert.ToDouble(cfg["random_interval"]).ToString("G",CultureInfo.InvariantCulture),Margin=new Thickness(0,10,0,0),Padding=new Thickness(5)};panel.Children.Add(box);
        var message=new TextBlock {Foreground=Brushes.DarkRed,TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,5,0,0)};panel.Children.Add(message);
        var footer=new StackPanel {Orientation=Orientation.Horizontal,HorizontalAlignment=HorizontalAlignment.Right,Margin=new Thickness(0,10,0,0)};
        var save=new Button {Content="保存",Padding=new Thickness(12,4,12,4),Margin=new Thickness(0,0,8,0)};
        var cancel=new Button {Content="取消",Padding=new Thickness(12,4,12,4)};footer.Children.Add(save);footer.Children.Add(cancel);panel.Children.Add(footer);dialog.Content=panel;
        save.Click+=(s,e)=>{try {ChangeInterval(ParseInterval(box.Text));dialog.Close();}catch(ArgumentException ex){message.Text=ex.Message;}catch(Exception ex){Log("设置随机间隔失败",ex);message.Text="无法保存："+ex.Message;}};
        cancel.Click+=(s,e)=>dialog.Close();dialog.Closed+=(s,e)=>{settingsOpen=false;Quiet();};dialog.ShowDialog();
    }
    static void TryRandomAction(object sender,EventArgs e) {
        if(!Convert.ToBoolean(cfg["auto_random"]) || dragging || mouseDown || settingsOpen || DateTime.UtcNow<quietUntil || (menu!=null && menu.IsOpen) || actionSeconds>0) return;
        Play(ChooseRandomAction());
    }
    static void Tick(object sender, EventArgs e) {
        if(dragging && !dragOverride) {
            image.Source=frames[dragDirection][FrameAtTime(dragClock.ElapsedMilliseconds,FrameTimings[dragDirection])];return;
        }
        long elapsed=animation.ElapsedMilliseconds;
        if(actionSeconds>0 && elapsed>=actionSeconds*1000) {
            row=IdleAction;animation.Restart();elapsed=0;actionSeconds=0;
            if(dragging){dragOverride=false;Tick(sender,e);return;}
        }
        frame = FrameAtTime(elapsed, FrameTimings[row]);
        ShowFrame(row, frame);
    }
    static int FrameAtTime(long elapsed,int[] durations) {
        long total=0;foreach(int ms in durations){if(ms<=0)throw new ArgumentException("帧时长必须大于零");total+=ms;}
        long t=elapsed%total;for(int i=0;i<durations.Length;i++){if(t<durations[i])return i;t-=durations[i];}return durations.Length-1;
    }
    static void BeginDragAnimation(double initialDx) {

        dragging=true;dragOverride=false;dragClock.Restart();row=IdleAction;frame=0;actionSeconds=0;animation.Restart();
        double dpi=source.CompositionTarget.TransformToDevice.M11;
        dragDirection=IdleAction+(Math.Abs(initialDx*dpi)>=2?(initialDx>0?1:2):0);dragLastX=window.Left;
        image.Source=frames[dragDirection][0];
        activeDragTimer=SetTimer(source.Handle,DragTimerId,30,IntPtr.Zero);
        if(activeDragTimer==UIntPtr.Zero)Log("拖动刷新计时器启动失败",new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error()));
    }
    static void UpdateDragDirection(double left) {
        if(!dragging)return;
        double dpi=source.CompositionTarget.TransformToDevice.M11;double delta=(left-dragLastX)*dpi;
        if(Math.Abs(delta)>=2){int next=IdleAction+(delta>0?1:2);dragLastX=left;if(next!=dragDirection){dragDirection=next;dragClock.Restart();}}
    }
    static void EndDragAnimation() {
        if(!dragging)return;
        if(activeDragTimer!=UIntPtr.Zero && source!=null){KillTimer(source.Handle,activeDragTimer);activeDragTimer=UIntPtr.Zero;}
        dragging=false;if(!dragOverride || actionSeconds<=0){row=IdleAction;frame=0;actionSeconds=0;animation.Restart();}
        ShowFrame(row,frame);Quiet();
    }
    static bool DragThreshold(Point start,Point current) {return Math.Abs(current.X-start.X)>=4 || Math.Abs(current.Y-start.Y)>=4;}
    static void Quiet() {quietUntil=DateTime.UtcNow.AddSeconds(3);}
    static bool CharacterAt(Point p) {
        var bitmap=image.Source as BitmapSource;if(bitmap==null || image.ActualWidth<=0 || image.ActualHeight<=0)return false;
        double factor=Math.Min(image.ActualWidth/bitmap.PixelWidth,image.ActualHeight/bitmap.PixelHeight);
        double left=(image.ActualWidth-bitmap.PixelWidth*factor)/2, top=(image.ActualHeight-bitmap.PixelHeight*factor)/2;
        int x=(int)Math.Floor((p.X-left)/factor),y=(int)Math.Floor((p.Y-top)/factor);
        if(x<0||y<0||x>=bitmap.PixelWidth||y>=bitmap.PixelHeight)return false;
        byte[] data;if(!alphaCache.TryGetValue(bitmap,out data)) {var converted=new FormatConvertedBitmap(bitmap,PixelFormats.Bgra32,null,0);data=new byte[bitmap.PixelWidth*bitmap.PixelHeight*4];converted.CopyPixels(data,bitmap.PixelWidth*4,0);alphaCache[bitmap]=data;}
        return data[(y*bitmap.PixelWidth+x)*4+3]>=16;
    }
    static void HandleHover(bool inside,Point screen) {
        if(pointerPositionKnown && Math.Abs(screen.X-lastPointerScreen.X)<0.5 && Math.Abs(screen.Y-lastPointerScreen.Y)<0.5)return;
        pointerPositionKnown=true;lastPointerScreen=screen;
        if(!inside){hovering=false;return;}
        if(hovering)return;
        hovering=true;var now=DateTime.UtcNow;
        if(!mouseDown && !dragging && !settingsOpen && (menu==null || !menu.IsOpen) && actionSeconds==0 && (now-lastHover).TotalSeconds>=12){lastHover=now;Play(IdleAction+4);Quiet();}
    }
    static void HoverAt(Point p) {
        if(PresentationSource.FromVisual(image)==null)return;
        HandleHover(CharacterAt(p),image.PointToScreen(p));
    }
    static MenuItem AddItem(ContextMenu menu,string label,Action action) {
        var item=new MenuItem {Header=label}; item.Click+=(s,e)=>action(); menu.Items.Add(item);return item;
    }
    static string FormatShortcut(string value) {
        string[] parts=value.Split('+');for(int i=0;i<parts.Length;i++)parts[i]=parts[i].Trim();
        int last=parts.Length-1; if(parts[last].Length==2 && (parts[last][0]=='D'||parts[last][0]=='d') && Char.IsDigit(parts[last][1]))parts[last]=parts[last].Substring(1);
        return String.Join("+",parts);
    }
    static string StartupValue { get {return "\""+typeof(GenshinPet).Assembly.Location+"\"";} }
    static bool StartupEnabled(RegistryKey key) { return String.Equals(key.GetValue(PetId) as string,StartupValue,StringComparison.OrdinalIgnoreCase); }
    static void SetStartup(RegistryKey key,bool enabled) {
        var value=key.GetValue(PetId) as string;
        if(enabled) {
            if(!String.IsNullOrEmpty(value) && !String.Equals(value,StartupValue,StringComparison.OrdinalIgnoreCase)) throw new InvalidOperationException("另一份桌宠已设置开机自启，请先在那份程序中关闭。");
            key.SetValue(PetId,StartupValue,RegistryValueKind.String);
        } else if(StartupEnabled(key)) key.DeleteValue(PetId,false);
    }
    const string RunKey="Software\\Microsoft\\Windows\\CurrentVersion\\Run";
    static bool ReadStartup() { using(var key=Registry.CurrentUser.OpenSubKey(RunKey,false)) return key!=null && StartupEnabled(key); }
    static void ChangeStartup(bool enabled) { using(var key=Registry.CurrentUser.CreateSubKey(RunKey)) {if(key==null)throw new IOException("无法打开登录启动设置");SetStartup(key,enabled);} }
    static void UnregisterAll() {if(source!=null)for(int i=1;i<=Counts.Length;i++)UnregisterHotKey(source.Handle,i);}
    static void ParseShortcut(string text,out uint mods,out uint vk) {
        var parts=text.Split('+');if(parts.Length<2)throw new Exception("需要组合键");mods=0;
        for(int i=0;i<parts.Length-1;i++)switch(parts[i].Trim().ToLowerInvariant()){case "ctrl":mods|=2;break;case "alt":mods|=1;break;case "shift":mods|=4;break;case "win":mods|=8;break;default:throw new Exception("修饰键无效");}
        var key=(Key)Enum.Parse(typeof(Key),parts[parts.Length-1].Trim(),true);int code=KeyInterop.VirtualKeyFromKey(key);
        if(code==0)throw new Exception("按键无效");vk=(uint)code;
    }
    static string RegisterBindings(Dictionary<string,object> bindings) {
        UnregisterAll();
        for (int i = 0; i < Names.Length; i++) actionItems[i].Header = Names[i];
        var seen=new HashSet<string>(); var errors=new List<string>();
        foreach(var p in bindings) {
            int idx=-1; string label=Convert.ToString(p.Value);
            try {
        
                if(!Int32.TryParse(p.Key,out idx) || !ValidAction(idx))throw new Exception("动作编号无效或尚未启用");
                uint mods,vk;ParseShortcut(label,out mods,out vk);
                if(!seen.Add(mods+":"+vk))throw new Exception("与其他动作重复");
                if(!RegisterHotKey(source.Handle,idx+1,mods,vk))throw new Exception("被系统或其他程序占用");
                actionItems[idx].Header=Names[idx]+"（"+FormatShortcut(label)+"）";
            } catch(Exception ex) {
                if(ValidAction(idx))actionItems[idx].Header=Names[idx]+"（"+FormatShortcut(label)+"，不可用）";
                errors.Add((ValidAction(idx)?Names[idx]:p.Key)+"："+FormatShortcut(label)+"，"+ex.Message);Log("快捷键注册失败",ex);
            }
        }
        return String.Join("\n",errors.ToArray());
    }
    static double CurrentScale() {
        double scale = Convert.ToDouble(cfg["scale"]);
        return scale == 1.0 || scale == 2.0 ? scale : 1.5;
    }

    static void ResizePet(double scale) {
        var dpi = source.CompositionTarget.TransformToDevice;
        double center = window.Left + window.Width / 2;
        double bottom = window.Top + window.Height;
        window.Width = Math.Round(FrameWidth * scale) / dpi.M11;
        window.Height = Math.Round(FrameHeight * scale) / dpi.M22;
        var work = SystemParameters.WorkArea;
        if (!window.IsVisible) {
            window.Left = Math.Max(work.Left, work.Right - window.Width - StartGap);
            window.Top = Math.Max(work.Top, work.Bottom - window.Height - 20);
        } else {
            window.Left = center - window.Width / 2;
            window.Top = bottom - window.Height;
            if (window.Top < work.Top && bottom > work.Top && bottom <= work.Bottom)
                window.Top = work.Top;
        }
        window.Left = Math.Round(window.Left * dpi.M11) / dpi.M11;
        window.Top = Math.Round(window.Top * dpi.M22) / dpi.M22;
    }

    static void SetScale(double scale) {
        object old; bool had=cfg.TryGetValue("scale",out old); cfg["scale"]=scale;
        try {Save(); ResizePet(scale); ShowFrame(row,frame);} catch(Exception ex) {if(had)cfg["scale"]=old;else cfg.Remove("scale");Log("保存显示尺寸失败",ex);MessageBox.Show("无法保存显示尺寸："+ex.Message);}
    }

    static void CheckWindow() {
        if (source == null || !window.IsVisible || !timer.IsEnabled || !randomTimer.IsEnabled)
            throw new InvalidOperationException("窗口或计时器未正常启动。");
        var dpi = source.CompositionTarget.TransformToDevice;
        foreach (double scale in new[] {1.5, 1.0, 2.0}) {
            ResizePet(scale);
            window.UpdateLayout();
            if (Math.Abs(window.ActualWidth * dpi.M11 - 192 * scale) > 1 ||
                Math.Abs(window.ActualHeight * dpi.M22 - 208 * scale) > 1)
                throw new InvalidOperationException("窗口尺寸不正确：" + scale);
        }
        ResizePet(1.5);
        Play(0);
        window.UpdateLayout();
        var capture = new RenderTargetBitmap(288,312,96*dpi.M11,96*dpi.M22,PixelFormats.Pbgra32);
        capture.Render(image);
        var png = new PngBitmapEncoder();png.Frames.Add(BitmapFrame.Create(capture));
        using(var file=File.Create(Path.Combine(Root,"150%-render.png")))png.Save(file);
        for (int choice = 0; choice < Appearances.Length; choice++) {
            appearance = choice;
            int randomAction = ChooseRandomAction();
            if (randomAction < IdleAction + 3 || randomAction >= IdleAction + RowCounts.Length)
                throw new InvalidOperationException("随机动作使用了另一套形象。");
            Play(IdleAction + 3);
            actionSeconds = 0.0001;
            System.Threading.Thread.Sleep(20);
            Tick(null, EventArgs.Empty);
            if (row != IdleAction || image.Source != frames[IdleAction][0])
                throw new InvalidOperationException("临时动作结束后没有恢复常驻形象。");
            BeginDragAnimation(8);
            try {
                if (dragDirection != IdleAction + 1) throw new InvalidOperationException("向右拖动形象错误。");
                UpdateDragDirection(window.Left - 8);
                if (dragDirection != IdleAction + 2) throw new InvalidOperationException("向左拖动形象错误。");
            } finally {
                EndDragAnimation();
            }
        }
    }
    static void EditShortcuts() {
        settingsOpen=true;UnregisterAll();bool saved=false;
        var dialog=new Window {Title="快捷键设置",Owner=window,Width=500,Height=650,WindowStartupLocation=WindowStartupLocation.CenterScreen,Topmost=true};
        var panel=new StackPanel {Margin=new Thickness(14)};
        panel.Children.Add(new TextBlock {Text="点击输入框并按组合键，需包含 Ctrl 或 Alt；清除后可用右键触发。",TextWrapping=TextWrapping.Wrap,Margin=new Thickness(0,0,0,10)});
        var boxes=new TextBox[Names.Length];
        for(int i=0;i<Names.Length;i++) {
            if(!ValidAction(i))continue;
            int index=i; var line=new DockPanel {Margin=new Thickness(0,3,0,3)};
            var name=new TextBlock {Text=Names[i],Width=120,VerticalAlignment=VerticalAlignment.Center};DockPanel.SetDock(name,Dock.Left);line.Children.Add(name);
            var clear=new Button {Content="清除",Width=56,Margin=new Thickness(8,0,0,0)};DockPanel.SetDock(clear,Dock.Right);line.Children.Add(clear);
            string initial=Get("hotkeys",i) as string; var box=new TextBox {IsReadOnly=true,MinWidth=180,Padding=new Thickness(5),Tag=initial,Text=String.IsNullOrEmpty(initial)?"未设置快捷键":FormatShortcut(initial)};
            boxes[i]=box;line.Children.Add(box);panel.Children.Add(line);
            clear.Click+=(s,e)=>{boxes[index].Tag=null;boxes[index].Text="未设置快捷键";};
            box.PreviewKeyDown+=(s,e)=>{
                e.Handled=true;Key key=e.Key==Key.System?e.SystemKey:e.Key;var modifiers=Keyboard.Modifiers;
                if(key==Key.LeftCtrl||key==Key.RightCtrl||key==Key.LeftAlt||key==Key.RightAlt||key==Key.LeftShift||key==Key.RightShift||key==Key.LWin||key==Key.RWin)return;
                if((modifiers & (ModifierKeys.Control|ModifierKeys.Alt))==0 || (modifiers & ModifierKeys.Windows)!=0 || KeyInterop.VirtualKeyFromKey(key)==0){box.ToolTip="请按包含 Ctrl 或 Alt 的组合键";return;}
                string v=((modifiers&ModifierKeys.Control)!=0?"Ctrl+":"")+((modifiers&ModifierKeys.Alt)!=0?"Alt+":"")+((modifiers&ModifierKeys.Shift)!=0?"Shift+":"")+key;
                box.Tag=v;box.Text=FormatShortcut(v);box.ToolTip=null;
            };
        }
        var footer=new StackPanel {Orientation=Orientation.Horizontal,HorizontalAlignment=HorizontalAlignment.Right,Margin=new Thickness(0,12,0,0)};
        var defaults=new Button {Content="清除全部",Padding=new Thickness(10,5,10,5),Margin=new Thickness(0,0,8,0)};
        var save=new Button {Content="保存",Padding=new Thickness(14,5,14,5),Margin=new Thickness(0,0,8,0)};
        var cancel=new Button {Content="取消",Padding=new Thickness(14,5,14,5)};
        footer.Children.Add(defaults);footer.Children.Add(save);footer.Children.Add(cancel);panel.Children.Add(footer);
        dialog.Content=new ScrollViewer {Content=panel,VerticalScrollBarVisibility=ScrollBarVisibility.Auto};
        defaults.Click+=(sender,args)=>{foreach(var box in boxes){box.Tag=null;box.Text="未设置快捷键";}};
        cancel.Click+=(s,e)=>dialog.Close();
        save.Click+=(s,e)=>{
            var candidate=new Dictionary<string,object>();
            for(int i=0;i<boxes.Length;i++){if(boxes[i]==null)continue;string key=boxes[i].Tag as string;if(!String.IsNullOrEmpty(key))candidate[i.ToString()]=key;}
            string errors=RegisterBindings(candidate);
            if(!String.IsNullOrEmpty(errors)){UnregisterAll();MessageBox.Show(dialog,"以下快捷键不可用，请修改后重试：\n"+errors,"快捷键设置");return;}
            object old=cfg["hotkeys"];cfg["hotkeys"]=candidate;
            try {Save();saved=true;dialog.Close();}
            catch(Exception ex){cfg["hotkeys"]=old;UnregisterAll();Log("保存快捷键失败",ex);MessageBox.Show(dialog,"保存失败，原设置仍保留："+ex.Message,"快捷键设置");}
        };
        dialog.Closed+=(s,e)=>{if(!saved){string errors=RegisterBindings(Map("hotkeys"));if(!String.IsNullOrEmpty(errors))MessageBox.Show("原快捷键部分恢复失败：\n"+errors);}settingsOpen=false;};
        dialog.ShowDialog();
    }
    static void Start() {
        window=new Window {Title=PetName+"单机桌宠", Width=192,Height=208,ResizeMode=ResizeMode.NoResize,WindowStyle=WindowStyle.None,AllowsTransparency=true,Background=Brushes.Transparent,Topmost=true,ShowInTaskbar=false,UseLayoutRounding=true,SnapsToDevicePixels=true};
        window.Left=SystemParameters.WorkArea.Right-window.Width-StartGap; window.Top=SystemParameters.WorkArea.Bottom-window.Height-20;
        image=new Image {SnapsToDevicePixels=true}; RenderOptions.SetBitmapScalingMode(image,BitmapScalingMode.NearestNeighbor); window.Content=image;
        Play(IdleAction);
        menu=new ContextMenu();
        actionItems=new MenuItem[Names.Length];
        for (int i = 0; i < Names.Length; i++) {
            int action = i;
            var item = new MenuItem {Header = Names[i]};
            item.Click += (sender, args) => Play(action);
            menu.Items.Add(item);
            actionItems[i] = item;
        }
        menu.Items.Add(new Separator());
        var auto=new MenuItem {Header="自动随机动作",IsCheckable=true,IsChecked=Convert.ToBoolean(cfg["auto_random"])};
        auto.Click+=(s,e)=>{bool old=Convert.ToBoolean(cfg["auto_random"]);cfg["auto_random"]=auto.IsChecked;try{Save();}catch(Exception ex){Log("保存自动动作设置失败",ex);cfg["auto_random"]=old;auto.IsChecked=old;MessageBox.Show("无法保存自动动作设置："+ex.Message);}};
        menu.Items.Add(auto);
        intervalItem=AddItem(menu,IntervalLabel(),EditInterval);
        AddItem(menu,"快捷键设置…",EditShortcuts);
        var startup=new MenuItem {Header="登录后自动启动",IsCheckable=true};menu.Items.Add(startup);
        menu.Opened+=(s,e)=>{mouseDown=false;Quiet();if(image.IsMouseCaptured)image.ReleaseMouseCapture();try{startup.IsChecked=ReadStartup();startup.IsEnabled=true;}catch(Exception ex){startup.IsEnabled=false;Log("读取登录启动设置失败",ex);}};
        menu.Closed+=(s,e)=>Quiet();
        startup.Click+=(s,e)=>{try{ChangeStartup(startup.IsChecked);startup.IsChecked=ReadStartup();}catch(Exception ex){Log("设置登录启动失败",ex);try{startup.IsChecked=ReadStartup();}catch{}MessageBox.Show("无法更改登录后启动："+ex.Message);}};
        var size=new MenuItem {Header="显示大小"}; menu.Items.Add(size);
        foreach(double n in new double[]{1.0,1.5,2.0}) {double v=n;var item=new MenuItem {Header=(int)(n*100)+"%"};item.Click+=(s,e)=>SetScale(v);size.Items.Add(item);}
        menu.Items.Add(new Separator()); AddItem(menu,"退出",()=>window.Close()); image.ContextMenu=menu;
        image.MouseMove+=(s,e)=>{
            Point p=e.GetPosition(image);HoverAt(p);
            if(mouseDown && e.LeftButton==MouseButtonState.Pressed && DragThreshold(downPoint,p)) {
                double initialDx=p.X-downPoint.X;
                mouseDown=false;Quiet();image.ReleaseMouseCapture();BeginDragAnimation(initialDx);
                try{window.DragMove();}finally{EndDragAnimation();}
            }
        };
        image.MouseLeave+=(s,e)=>{if(PresentationSource.FromVisual(image)==null){hovering=false;return;}Point p=e.GetPosition(image);HandleHover(false,image.PointToScreen(p));};
        image.MouseLeftButtonDown+=(s,e)=>{Point p=e.GetPosition(image);if(CharacterAt(p)){downPoint=p;mouseDown=true;Quiet();image.CaptureMouse();e.Handled=true;}};
        image.MouseLeftButtonUp+=(s,e)=>{Point p=e.GetPosition(image);bool click=mouseDown && CharacterAt(p);mouseDown=false;if(image.IsMouseCaptured)image.ReleaseMouseCapture();Quiet();if(click && (DateTime.UtcNow-lastClick).TotalSeconds>=1 && actionSeconds==0){lastClick=DateTime.UtcNow;Play(IdleAction+3);}e.Handled=click;};
        image.LostMouseCapture+=(s,e)=>{mouseDown=false;};
        image.MouseRightButtonDown+=(s,e)=>{mouseDown=false;Quiet();if(image.IsMouseCaptured)image.ReleaseMouseCapture();};
        window.Deactivated+=(s,e)=>{mouseDown=false;if(image.IsMouseCaptured)image.ReleaseMouseCapture();};
        window.LocationChanged+=(s,e)=>{UpdateDragDirection(window.Left);};
        timer=new DispatcherTimer {Interval=TimeSpan.FromMilliseconds(16)}; timer.Tick+=Tick;
        randomTimer=new DispatcherTimer {Interval=TimeSpan.FromSeconds(Convert.ToDouble(cfg["random_interval"]))}; randomTimer.Tick+=TryRandomAction;
        window.SourceInitialized+=(s,e)=>{
            source=HwndSource.FromHwnd(new WindowInteropHelper(window).Handle);source.AddHook(Hook);
            ResizePet(CurrentScale());
            string errors=RegisterBindings(Map("hotkeys"));if(!String.IsNullOrEmpty(errors)){if(smokeMode){runtimeFailed=true;Log("启动检查时快捷键不可用",new InvalidOperationException(errors));}else MessageBox.Show("以下快捷键不可用：\n"+errors);}
        };
        window.Closed+=(s,e)=>{timer.Stop();randomTimer.Stop();if(activeDragTimer!=UIntPtr.Zero && source!=null){KillTimer(source.Handle,activeDragTimer);activeDragTimer=UIntPtr.Zero;}UnregisterAll();};
        timer.Start(); randomTimer.Start(); var app=new Application(); app.DispatcherUnhandledException+=(s,e)=>{runtimeFailed=true;Log("界面异常",e.Exception);if(!smokeMode)MessageBox.Show("桌宠发生错误，详情已保存到日志："+e.Exception.Message);e.Handled=true;app.Shutdown();};
        if (smokeMode) {
            int next = 0;
            var smoke = new DispatcherTimer {Interval = TimeSpan.FromMilliseconds(80)};
            smoke.Tick += (sender, args) => {
                if (next < Counts.Length) {
                    Play(next);
                    if (image.Source != frames[next][0])
                        throw new InvalidOperationException("动作首帧未显示：" + Names[next]);
                    next++;
                    return;
                }
                smoke.Stop();
                CheckWindow();
                window.Close();
            };
            smoke.Start();
        }
        app.Run(window);
    }
    static IntPtr Hook(IntPtr h,int msg,IntPtr wp,IntPtr lp,ref bool handled) {
        if(msg==0x113 && activeDragTimer!=UIntPtr.Zero && unchecked((ulong)wp.ToInt64())==activeDragTimer.ToUInt64()) {if(dragging)Tick(null,EventArgs.Empty);handled=true;return IntPtr.Zero;}
        if(msg==0x312){long id=wp.ToInt64(); if(id>=1 && id<=Counts.Length && ValidAction((int)id-1)){if(!settingsOpen)Play((int)id-1);handled=true;}} return IntPtr.Zero;
    }
    [STAThread] static int Main(string[] args) {
        try {smokeMode=args.Contains("--smoke");Load(); if(args.Contains("--check")){bool handled=false; Hook(IntPtr.Zero,0,new IntPtr(Int64.MaxValue),IntPtr.Zero,ref handled); Hook(IntPtr.Zero,0x312,new IntPtr(Int64.MaxValue),IntPtr.Zero,ref handled); return 0;}
            bool created; using(var mutex=new Mutex(true,"Local\\" + PetId,out created)) {if(!created){if(!smokeMode)MessageBox.Show("桌宠已经运行，请先从现有桌宠的右键菜单退出。");return smokeMode?2:0;} Start();}return runtimeFailed?1:0;}
        catch(Exception ex){Log("启动或运行失败",ex);if(!args.Contains("--check")&&!args.Contains("--smoke"))MessageBox.Show("桌宠启动失败："+ex.Message+"\n详情请查看"+PetName+"桌宠错误日志.txt");return 1;}
    }
}

