from pathlib import Path
import zipfile
root=Path('.')
p=root/'使用说明.md';s=p.read_text(encoding='utf-8').replace('的全部 57 帧','的九组动作共 57 帧').replace('及原有脚底浅色区域','');s += '\n原始图集还包含 16 个视线方向帧，保存在 source/original.png；本离线版未实现视线跟随。\n';p.write_text(s,encoding='utf-8')
(root/'adapt.py').unlink()
with zipfile.ZipFile('../比比拉布桌宠单机版.zip','w',zipfile.ZIP_DEFLATED) as z:
 for f in root.rglob('*'):
  if f.is_file(): z.write(f,Path('比比拉布桌宠单机版')/f)
