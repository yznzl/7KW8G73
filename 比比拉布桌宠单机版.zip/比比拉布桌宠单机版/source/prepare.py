"""Enhance the original Codex atlas without generating or repositioning any artwork."""
from pathlib import Path
import json
from PIL import Image, ImageDraw, ImageFont, ImageFilter
import numpy as np
import hashlib

ROOT = Path(__file__).resolve().parent
NAMES = ['idle', 'right', 'left', 'laugh', 'fall', 'lying', 'recover', 'belly', 'look']
COUNTS = [6, 8, 8, 4, 5, 8, 6, 6, 6]
HEIGHTS = [[360]*6, [360]*8, [360]*8, [360]*4,
           [360, 330, 360, 190, 190], [190]*8,
           [330, 350, 360, 360, 360, 350], [330, 340, 360, 360, 360, 350], [360]*6]

def main():
    atlas = Image.new('RGBA', (384*8, 416*9))
    report = []
    original = Image.open(ROOT/'original.png').convert('RGBA')
    assert original.size == (1536,2288)
    for row, (name,count) in enumerate(zip(NAMES,COUNTS)):
        for index in range(count):
            frame = original.crop((index*192,row*208,(index+1)*192,(row+1)*208))
            # Premultiplied-alpha resampling prevents hidden background RGB from bleeding.
            enlarged = frame.convert('RGBa').resize((384,416),Image.Resampling.LANCZOS).convert('RGBA')
            rgb = enlarged.convert('RGB')
            sharp = rgb.filter(ImageFilter.UnsharpMask(radius=1.25,percent=135,threshold=3))
            # Keep transparency and geometry unchanged; sharpen only the opaque interior.
            safe = enlarged.getchannel('A').point(lambda v: 255 if v>=245 else 0).filter(ImageFilter.MinFilter(5))
            enhanced = Image.composite(sharp,rgb,safe).convert('RGBA')
            enhanced.putalpha(enlarged.getchannel('A'))
            assert enhanced.getchannel('A').tobytes()==enlarged.getchannel('A').tobytes()
            src = np.asarray(frame.getchannel('A'))>=128
            back = np.asarray(enhanced.getchannel('A').resize((192,208),Image.Resampling.LANCZOS))>=128
            iou = float((src & back).sum()/max(1,(src | back).sum()))
            assert iou>0.99,(name,index,iou)
            atlas.paste(enhanced,(index*384,row*416))
            report.append({'action':name,'frame':index,'silhouette_iou':iou,'alpha_unchanged_after_sharpen':True})
    (ROOT/'assets').mkdir(exist_ok=True)
    atlas.save(ROOT/'assets/nailong.png', optimize=True)
    # Compare at exactly the 288×312 physical pixels used by the app's 150% mode.
    font = ImageFont.truetype('C:/Windows/Fonts/msyh.ttc', 18)
    preview = Image.new('RGB',(288*6,350*3),'#c4cdd4')
    draw = ImageDraw.Draw(preview)
    original = Image.open(ROOT/'original.png').convert('RGBA')
    labels = ['待机','右走','左走','挥手','跳跃','哭泣','等待','忙碌','开心']
    for row in range(9):
        for kind in range(2):
            x = ((row%3)*2+kind)*288; y=(row//3)*350
            image = (original.crop((0,row*208,192,(row+1)*208)) if kind==0 else atlas.crop((0,row*416,384,(row+1)*416)))
            image = image.resize((288,312), Image.Resampling.LANCZOS)
            preview.paste(image,(x,y+36),image)
            draw.text((x+8,y+7),labels[row]+(' · 原图放大' if kind==0 else ' · 原貌增强'),font=font,fill='#162431')
    preview.save(ROOT.parent/'150%清晰度对照.png')
    # Full frame contact sheet for visual continuity checks.
    contact = Image.new('RGB',(192*8,232*9),'#c4cdd4')
    d = ImageDraw.Draw(contact)
    for row,count in enumerate(COUNTS):
        for index in range(count):
            f = atlas.crop((index*384,row*416,(index+1)*384,(row+1)*416)).resize((192,208),Image.Resampling.LANCZOS)
            contact.paste(f,(index*192,row*232+24),f)
            d.text((index*192+8,row*232+2),f'{labels[row]} {index+1}',font=font,fill='#162431')
    contact.save(ROOT.parent/'全部动作检查.png')
    assert len(report)==57
    (ROOT.parent/'素材检查.json').write_text(json.dumps({'method':'premultiplied-alpha Lanczos 2x + masked unsharp; no generative artwork', 'source_sha256':hashlib.sha256((ROOT/'original.png').read_bytes()).hexdigest(),'frames':57,'frame_size':[384,416],'display_150':[288,312],'checks':report},ensure_ascii=False,indent=2),encoding='utf-8')
    print('57 original frames validated; geometry preserved; 2x non-generative enhancement.')

if __name__=='__main__': main()
