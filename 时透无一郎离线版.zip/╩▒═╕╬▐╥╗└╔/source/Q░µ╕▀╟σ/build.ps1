﻿$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$framework = Join-Path $env:WINDIR 'Microsoft.NET\Framework64\v4.0.30319'
if (!(Test-Path -LiteralPath (Join-Path $framework 'csc.exe'))) { throw '需要 Windows 自带的 .NET Framework 4.x。' }
& (Join-Path $framework 'csc.exe') /nologo /target:winexe /platform:anycpu /optimize+ "/out:$projectRoot\时透无一郎Q版高清桌宠.exe" "/win32manifest:$PSScriptRoot\pet.manifest" "/resource:$PSScriptRoot\frames.png,frames.png" /r:System.Web.Extensions.dll /r:System.Windows.Forms.dll /r:System.Drawing.dll /r:System.Xaml.dll "/r:$framework\WPF\WindowsBase.dll" "/r:$framework\WPF\PresentationCore.dll" "/r:$framework\WPF\PresentationFramework.dll" "$PSScriptRoot\DemonSlayermuichirotokito.cs"
if ($LASTEXITCODE -ne 0) { throw '编译失败。' }

